// Общее для окошка (popup.js) и фоновой части (background.js): адрес API,
// тексты интерфейса и перевод ошибок сервера на человеческий язык.

export const SITE = "https://videoner.download";
// Канал новостей проекта — ссылка под «Готово» (popup.js).
export const NEWS_URL = "https://t.me/videonerdownload";
// Вход в API для расширения: тот же набор действий, что у сайта, но без капчи
// (см. web/app/api/ext/[...path]/route.ts).
const API = `${SITE}/api/ext`;

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

export function api(path, body) {
  return request(`${API}${path}`, body);
}

// Статус скачивания — публичный адрес сервера (им же пользуется прогресс на
// сайте), а не вход для расширения: опрос раз в пару секунд съел бы весь его
// лимит, а GET из фоновой части Chrome отправляет без заголовка Origin, по
// которому этот вход узнаёт расширение.
export function downloadStatus(downloadId) {
  return request(`${SITE}/download/${encodeURIComponent(downloadId)}/status`);
}

async function request(url, body) {
  let res;
  try {
    res = await fetch(url, {
      method: body ? "POST" : "GET",
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError("network", 0);
  }
  let data = null;
  try {
    data = await res.json();
  } catch {
    // Прокси или Cloudflare могли ответить HTML-страницей ошибки.
  }
  if (!res.ok) {
    const raw = data?.message ?? data?.error ?? `HTTP ${res.status}`;
    throw new ApiError(Array.isArray(raw) ? raw.join("; ") : String(raw), res.status);
  }
  return data;
}

// Готовый файл сервер отдаёт по /download/<имя файла>. Статус скачивания
// присылает путь вида /downloads/<имя> — из него берём только имя.
export function fileUrl(pathOrName) {
  const name = String(pathOrName).split("/").pop();
  return `${SITE}/download/${encodeURIComponent(name)}`;
}

// Домены площадок, которые поддерживает Videoner (точная проверка ссылки — на
// сервере, см. server/src/validate/url.ts). Нужно, чтобы на посторонних
// страницах окошко сразу говорило «тут нечего скачивать», не тратя запрос.
const PLATFORM_HOSTS = [
  /(^|\.)youtube\.com$/, /^youtu\.be$/,
  /(^|\.)tiktok\.com$/,
  /(^|\.)instagram\.com$/,
  /(^|\.)facebook\.com$/, /^fb\.watch$/,
  /(^|\.)twitter\.com$/, /(^|\.)x\.com$/,
  /(^|\.)vimeo\.com$/,
  /(^|\.)vk\.com$/, /(^|\.)vk\.ru$/, /(^|\.)vkvideo\.ru$/,
  /(^|\.)rutube\.ru$/,
  /(^|\.)ok\.ru$/,
  /(^|\.)pinterest\.[a-z.]{2,}$/, /^pin\.it$/,
  /(^|\.)threads\.(net|com)$/,
];

// id плейлиста YouTube из ссылки (/playlist?list=… или ролик с &list=…).
// Миксы (RD…) и личные списки (LL, WL) — не плейлисты. Та же логика, что
// server/src/lib/youtube-playlist.ts.
export function youtubePlaylistId(url) {
  try {
    const u = new URL(url);
    if (!/(^|\.)(youtube\.com|youtu\.be)$/i.test(u.hostname)) return null;
    const list = u.searchParams.get("list");
    if (!list || !/^[\w-]{10,64}$/.test(list) || /^(RD|LL|WL|UL)/.test(list)) return null;
    return list;
  } catch {
    return null;
  }
}

export function isPlaylistPage(url) {
  try {
    return Boolean(youtubePlaylistId(url)) && new URL(url).pathname.replace(/\/$/, "") === "/playlist";
  } catch {
    return false;
  }
}

export function isPlatformUrl(url) {
  try {
    const { protocol, hostname } = new URL(url);
    if (protocol !== "https:" && protocol !== "http:") return false;
    return PLATFORM_HOSTS.some((re) => re.test(hostname.toLowerCase()));
  } catch {
    return false;
  }
}

// Имя файла для «Загрузок»: без символов, которые Windows и Chrome не
// пропустят, и не длиннее разумного.
export function safeFileName(title, fallback = "video") {
  const cleaned = String(title ?? "")
    .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^[\s.]+|[\s.]+$/g, "")
    .slice(0, 120);
  return cleaned || fallback;
}

const TEXTS = {
  ru: {
    loading: "Получаю информацию о видео…",
    notVideoPage:
      "Откройте страницу с видео на YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest или Threads и нажмите на значок ещё раз. Урок GetCourse: если страница урока была открыта до установки расширения, обновите её.",
    gcLesson: "Урок GetCourse",
    gcPick: "В уроке несколько видео — выберите нужное",
    gcVideo: (n) => `Видео ${n}`,
    gcNote: "Качает и склеивает ваш браузер. Окошко можно закрыть, браузер — нет.",
    gcNoStream: "Не удалось получить видео из плеера. Обновите страницу урока и попробуйте снова.",
    video: "Видео",
    photo: "Фото в исходном размере",
    slideshow: "Слайдшоу (видео)",
    gallery: "Фото + слайдшоу",
    audioOnly: "Только звук (mp3)",
    subtitles: "Субтитры (.srt)",
    subtitlesAuto: "автоматические",
    back: "Назад",
    starting: "Запускаю скачивание…",
    waiting: "Жду своей очереди на сервере…",
    downloading: "Скачиваю",
    converting: "Обрабатываю",
    left: (eta) => `осталось ${eta}`,
    saving: "Сохраняю в «Загрузки»…",
    done: "Готово — файл в «Загрузках».",
    news: "📣 Новости проекта: @videonerdownload",
    again: "Скачать ещё",
    directDownload: "Скачать видео (mp4)",
    directPhoto: "Скачать фото (jpg)",
    directNote: "Сразу из браузера — без очереди на сервере",
    moreOptions: "Другие качества и звук",
    fallback: "Из браузера не получилось — скачиваю через сервер.",
    openSite: "Открыть videoner.download",
    retry: "Попробовать снова",
    min: "мин",
    sec: "с",
    errNetwork: "Нет связи с Videoner. Проверьте интернет и попробуйте ещё раз.",
    errRateLimit: "Слишком много запросов подряд. Подождите минуту и попробуйте снова.",
    errUnsupported:
      "На этой странице не нашлось видео, которое умеет скачивать Videoner. Откройте страницу конкретного ролика или поста.",
    errYoutubeDaily: "Дневной лимит YouTube для вашей сети исчерпан. Попробуйте завтра.",
    errTooLarge: "Файл в этом качестве слишком большой. Выберите качество пониже.",
    errLogin:
      "Эта запись недоступна без входа в аккаунт: площадка отдаёт её только авторизованным. Публичные записи скачиваются без проблем.",
    errRegion: "Автор ограничил просмотр этой записи по странам — скачать её не получится.",
    errServerBlocked: "Площадка временно ограничила доступ нашему серверу. Попробуйте позже.",
    errFailed: "Не получилось скачать. Попробуйте ещё раз или выберите другое качество.",
    errGeneric: "Что-то пошло не так. Попробуйте ещё раз чуть позже.",
    acctButton: (p) => `🔑 Подключить аккаунт ${p} к боту`,
    acctWarn: (p) =>
      `Бот @VideonerBot сможет скачивать от вашего аккаунта ${p} то, что видно только вошедшим: сторис, закрытые записи. Площадки не любят автоматические скачивания и могут ограничить аккаунт — лучше подключать не основной. Браузер спросит разрешение на куки этого сайта; на сервер уйдут только куки ${p}, зашифрованно.`,
    acctConfirm: "Подключить",
    acctCancel: "Отмена",
    acctSending: "Подключаю…",
    acctDenied: "Без разрешения на куки подключить аккаунт не получится.",
    acctNoLogin: (p) => `Вы не вошли в ${p} в этом браузере. Войдите на сайте и нажмите ещё раз.`,
    acctFailed: "Не получилось. Попробуйте ещё раз чуть позже.",
    acctCodeTitle: (p) => `Код для подключения ${p}:`,
    acctCodeHelp:
      "Отправьте его боту @VideonerBot в личку — для своих скачиваний. Для группы — отправьте в группе /connect КОД. Код действует 10 минут.",
    acctCopy: "Скопировать",
    acctCopied: "Скопировано",
    acctOpenBot: "Открыть бота",
    acctNewCode: "Получить новый код",
    acctList: "Мои подключения в боте",
    acctRevoke: "Отозвать доступ к куки",
    acctRevoked:
      "Доступ к куки снят — расширение больше их не читает. Уже подключённые аккаунты остаются в боте: отключить их можно в «Мои подключения в боте».",
    playlistOffer: "📃 Скачать весь плейлист",
    playlistTitle: (title, n) => `📃 Плейлист${title ? ` «${title}»` : ""}: ${n} видео`,
    playlistHint: "Скачаю по одному, по очереди. Окошко можно закрыть.",
    playlist720: "Плейлист в 720p",
    playlistBest: "Плейлист в лучшем качестве",
    playlistAudio: "Плейлист — только звук (mp3)",
    playlistProgress: (i, n) => `Видео ${i} из ${n}`,
    playlistStats: (done, failed) => `Скачано: ${done}${failed ? ` · не вышло: ${failed}` : ""}`,
    playlistStop: "⏹ Остановить",
    playlistDone: (done, n) => `Плейлист скачан: ${done} из ${n}.`,
    playlistStopped: (done, n) => `Остановлено. Скачано ${done} из ${n}.`,
    playlistLoading: "Получаю список видео…",
    close: "Закрыть",
    updateAvailable: (v) => `Вышла новая версия ${v}.`,
    updateHow: "Как обновить",
    langAuto: "Авто",
    langLabel: "Язык",
  },
  uk: {
    loading: "Отримую інформацію про відео…",
    notVideoPage:
      "Відкрийте сторінку з відео на YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest або Threads і натисніть на значок ще раз. Урок GetCourse: якщо сторінку уроку було відкрито до встановлення розширення, оновіть її.",
    gcLesson: "Урок GetCourse",
    gcPick: "В уроці кілька відео — оберіть потрібне",
    gcVideo: (n) => `Відео ${n}`,
    gcNote: "Завантажує й склеює ваш браузер. Віконце можна закрити, браузер — ні.",
    gcNoStream: "Не вдалося отримати відео з плеєра. Оновіть сторінку уроку й спробуйте знову.",
    video: "Відео",
    photo: "Фото в оригінальному розмірі",
    slideshow: "Слайдшоу (відео)",
    gallery: "Фото + слайдшоу",
    audioOnly: "Лише звук (mp3)",
    subtitles: "Субтитри (.srt)",
    subtitlesAuto: "автоматичні",
    back: "Назад",
    starting: "Запускаю завантаження…",
    waiting: "Чекаю своєї черги на сервері…",
    downloading: "Завантажую",
    converting: "Обробляю",
    left: (eta) => `залишилося ${eta}`,
    saving: "Зберігаю в «Завантаження»…",
    done: "Готово — файл у «Завантаженнях».",
    news: "📣 Новини проєкту: @videonerdownload",
    again: "Завантажити ще",
    directDownload: "Завантажити відео (mp4)",
    directPhoto: "Завантажити фото (jpg)",
    directNote: "Одразу з браузера — без черги на сервері",
    moreOptions: "Інші якості та звук",
    fallback: "З браузера не вийшло — завантажую через сервер.",
    openSite: "Відкрити videoner.download",
    retry: "Спробувати знову",
    min: "хв",
    sec: "с",
    errNetwork: "Немає зв'язку з Videoner. Перевірте інтернет і спробуйте ще раз.",
    errRateLimit: "Забагато запитів поспіль. Зачекайте хвилину й спробуйте знову.",
    errUnsupported:
      "На цій сторінці не знайшлося відео, яке вміє завантажувати Videoner. Відкрийте сторінку конкретного ролика чи допису.",
    errYoutubeDaily: "Денний ліміт YouTube для вашої мережі вичерпано. Спробуйте завтра.",
    errTooLarge: "Файл у цій якості завеликий. Оберіть якість нижчу.",
    errLogin:
      "Цей допис недоступний без входу в акаунт: платформа віддає його лише авторизованим. Публічні дописи завантажуються без проблем.",
    errRegion: "Автор обмежив перегляд цього допису за країнами — завантажити його не вийде.",
    errServerBlocked: "Платформа тимчасово обмежила доступ нашому серверу. Спробуйте пізніше.",
    errFailed: "Не вдалося завантажити. Спробуйте ще раз або оберіть іншу якість.",
    errGeneric: "Щось пішло не так. Спробуйте ще раз трохи пізніше.",
    acctButton: (p) => `🔑 Підключити акаунт ${p} до бота`,
    acctWarn: (p) =>
      `Бот @VideonerBot зможе завантажувати від вашого акаунта ${p} те, що видно лише тим, хто увійшов: сторіс, закриті дописи. Платформи не люблять автоматичних завантажень і можуть обмежити акаунт — краще підключати не основний. Браузер запитає дозвіл на куки цього сайту; на сервер підуть лише куки ${p}, зашифровано.`,
    acctConfirm: "Підключити",
    acctCancel: "Скасувати",
    acctSending: "Підключаю…",
    acctDenied: "Без дозволу на куки підключити акаунт не вийде.",
    acctNoLogin: (p) => `Ви не увійшли в ${p} у цьому браузері. Увійдіть на сайті й натисніть ще раз.`,
    acctFailed: "Не вийшло. Спробуйте ще раз трохи пізніше.",
    acctCodeTitle: (p) => `Код для підключення ${p}:`,
    acctCodeHelp:
      "Надішліть його боту @VideonerBot в особисті — для своїх завантажень. Для групи — надішліть у групі /connect КОД. Код діє 10 хвилин.",
    acctCopy: "Скопіювати",
    acctCopied: "Скопійовано",
    acctOpenBot: "Відкрити бота",
    acctNewCode: "Отримати новий код",
    acctList: "Мої підключення в боті",
    acctRevoke: "Відкликати доступ до куків",
    acctRevoked:
      "Доступ до куків знято — розширення більше їх не читає. Уже підключені акаунти лишаються в боті: вимкнути їх можна в «Мої підключення в боті».",
    playlistOffer: "📃 Завантажити весь плейлист",
    playlistTitle: (title, n) => `📃 Плейлист${title ? ` «${title}»` : ""}: ${n} відео`,
    playlistHint: "Завантажу по одному, по черзі. Віконце можна закрити.",
    playlist720: "Плейлист у 720p",
    playlistBest: "Плейлист у найкращій якості",
    playlistAudio: "Плейлист — лише звук (mp3)",
    playlistProgress: (i, n) => `Відео ${i} з ${n}`,
    playlistStats: (done, failed) => `Завантажено: ${done}${failed ? ` · не вийшло: ${failed}` : ""}`,
    playlistStop: "⏹ Зупинити",
    playlistDone: (done, n) => `Плейлист завантажено: ${done} з ${n}.`,
    playlistStopped: (done, n) => `Зупинено. Завантажено ${done} з ${n}.`,
    playlistLoading: "Отримую список відео…",
    close: "Закрити",
    updateAvailable: (v) => `Вийшла нова версія ${v}.`,
    updateHow: "Як оновити",
    langAuto: "Авто",
    langLabel: "Мова",
  },
  kk: {
    loading: "Видео туралы ақпарат алынуда…",
    notVideoPage:
      "YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest немесе Threads сайтында видеосы бар бетті ашып, белгішені қайта басыңыз. GetCourse сабағы: егер сабақ беті кеңейтімді орнатпас бұрын ашылған болса, оны жаңартыңыз.",
    gcLesson: "GetCourse сабағы",
    gcPick: "Сабақта бірнеше видео бар — керегін таңдаңыз",
    gcVideo: (n) => `Видео ${n}`,
    gcNote: "Жүктеп алу мен біріктіруді браузеріңіз жасайды. Терезені жабуға болады, браузерді — жоқ.",
    gcNoStream: "Ойнатқыштан видеоны алу мүмкін болмады. Сабақ бетін жаңартып, қайта байқап көріңіз.",
    video: "Видео",
    photo: "Түпнұсқа өлшемдегі фото",
    slideshow: "Слайдшоу (видео)",
    gallery: "Фото + слайдшоу",
    audioOnly: "Тек дыбыс (mp3)",
    subtitles: "Субтитрлер (.srt)",
    subtitlesAuto: "автоматты",
    back: "Артқа",
    starting: "Жүктеп алуды бастап жатырмын…",
    waiting: "Сервердегі кезегімді күтіп тұрмын…",
    downloading: "Жүктеп алынуда",
    converting: "Өңделуде",
    left: (eta) => `${eta} қалды`,
    saving: "«Жүктеулер» қалтасына сақталуда…",
    done: "Дайын — файл «Жүктеулер» қалтасында.",
    news: "📣 Жоба жаңалықтары: @videonerdownload",
    again: "Тағы жүктеп алу",
    directDownload: "Видеоны жүктеп алу (mp4)",
    directPhoto: "Фотоны жүктеп алу (jpg)",
    directNote: "Тікелей браузерден — сервердегі кезексіз",
    moreOptions: "Басқа сапалар және дыбыс",
    fallback: "Браузерден болмады — сервер арқылы жүктеп аламын.",
    openSite: "videoner.download сайтын ашу",
    retry: "Қайта байқап көру",
    min: "мин",
    sec: "с",
    errNetwork: "Videoner-мен байланыс жоқ. Интернетті тексеріп, қайта байқап көріңіз.",
    errRateLimit: "Қатарынан тым көп сұраныс. Бір минут күтіп, қайта байқап көріңіз.",
    errUnsupported:
      "Бұл беттен Videoner жүктеп ала алатын видео табылмады. Нақты видеоның немесе жазбаның бетін ашыңыз.",
    errYoutubeDaily: "Желіңіз үшін YouTube-тың тәуліктік лимиті таусылды. Ертең байқап көріңіз.",
    errTooLarge: "Бұл сападағы файл тым үлкен. Төменірек сапаны таңдаңыз.",
    errLogin:
      "Бұл жазба аккаунтқа кірмейінше қолжетімсіз: платформа оны тек авторизацияланған пайдаланушыларға береді. Ашық жазбалар еш қиындықсыз жүктеледі.",
    errRegion: "Автор бұл жазбаны көруді елдер бойынша шектеген — оны жүктеп алу мүмкін емес.",
    errServerBlocked: "Платформа біздің серверге қолжетімділікті уақытша шектеді. Кейінірек байқап көріңіз.",
    errFailed: "Жүктеп алу мүмкін болмады. Қайта байқап көріңіз немесе басқа сапаны таңдаңыз.",
    errGeneric: "Бірдеңе дұрыс болмады. Сәл кейінірек қайта байқап көріңіз.",
    acctButton: (p) => `🔑 ${p} аккаунтын ботқа қосу`,
    acctWarn: (p) =>
      `@VideonerBot боты сіздің ${p} аккаунтыңыз арқылы тек кіргендерге көрінетін нәрселерді жүктеп ала алады: сторис, жабық жазбалар. Платформалар автоматты жүктеп алуды ұнатпайды және аккаунтты шектеуі мүмкін — негізгі емес аккаунтты қосқан дұрыс. Браузер осы сайттың куки файлдарына рұқсат сұрайды; серверге тек ${p} куки файлдары шифрланған түрде жіберіледі.`,
    acctConfirm: "Қосу",
    acctCancel: "Бас тарту",
    acctSending: "Қосып жатырмын…",
    acctDenied: "Кукиге рұқсатсыз аккаунтты қосу мүмкін емес.",
    acctNoLogin: (p) => `Сіз бұл браузерде ${p} жүйесіне кірмегенсіз. Сайтқа кіріп, қайта басыңыз.`,
    acctFailed: "Болмады. Сәл кейінірек қайта байқап көріңіз.",
    acctCodeTitle: (p) => `${p} қосуға арналған код:`,
    acctCodeHelp:
      "Оны @VideonerBot ботына жеке чатта жіберіңіз — өз жүктеп алуларыңыз үшін. Топ үшін — топта /connect КОД жіберіңіз. Код 10 минут жарамды.",
    acctCopy: "Көшіру",
    acctCopied: "Көшірілді",
    acctOpenBot: "Ботты ашу",
    acctNewCode: "Жаңа код алу",
    acctList: "Боттағы қосылымдарым",
    acctRevoke: "Кукиге рұқсатты қайтарып алу",
    acctRevoked:
      "Кукиге рұқсат алынды — кеңейтім оларды енді оқымайды. Бұрын қосылған аккаунттар ботта қалады: оларды «Боттағы қосылымдарым» бөлімінде ажыратуға болады.",
    playlistOffer: "📃 Бүкіл плейлистті жүктеп алу",
    playlistTitle: (title, n) => `📃 Плейлист${title ? ` «${title}»` : ""}: ${n} видео`,
    playlistHint: "Бір-бірлеп, кезекпен жүктеп аламын. Терезені жабуға болады.",
    playlist720: "Плейлист 720p сапада",
    playlistBest: "Плейлист ең жақсы сапада",
    playlistAudio: "Плейлист — тек дыбыс (mp3)",
    playlistProgress: (i, n) => `Видео ${i} / ${n}`,
    playlistStats: (done, failed) => `Жүктелді: ${done}${failed ? ` · болмады: ${failed}` : ""}`,
    playlistStop: "⏹ Тоқтату",
    playlistDone: (done, n) => `Плейлист жүктелді: ${done} / ${n}.`,
    playlistStopped: (done, n) => `Тоқтатылды. Жүктелді: ${done} / ${n}.`,
    playlistLoading: "Видео тізімін аламын…",
    close: "Жабу",
    updateAvailable: (v) => `Жаңа ${v} нұсқасы шықты.`,
    updateHow: "Қалай жаңартуға болады",
    langAuto: "Авто",
    langLabel: "Тіл",
  },
  // Арабский (MSA). ⁦…⁩ (LRI…PDI) и ⁨…⁩ (FSI…PDI) —
  // невидимые изоляты направления: без них в RTL-тексте «@VideonerBot» и
  // «/connect» показались бы как «VideonerBot@» и «connect/».
  ar: {
    loading: "جارٍ جلب معلومات الفيديو…",
    notVideoPage:
      "افتح صفحة فيديو على YouTube أو TikTok أو Instagram أو Facebook أو X أو Vimeo أو VK أو Rutube أو OK.ru أو Pinterest أو Threads، ثم انقر على الأيقونة مرة أخرى. درس GetCourse: إذا كانت صفحة الدرس مفتوحة قبل تثبيت الإضافة، فأعد تحميلها.",
    gcLesson: "درس GetCourse",
    gcPick: "يحتوي هذا الدرس على عدة مقاطع فيديو — اختر واحدًا",
    gcVideo: (n) => `فيديو ${n}`,
    gcNote: "يتولى متصفحك تنزيل الفيديو ودمجه. يمكنك إغلاق هذه النافذة، لكن لا تغلق المتصفح.",
    gcNoStream: "تعذّر الحصول على الفيديو من المشغّل. أعد تحميل صفحة الدرس وحاول مرة أخرى.",
    video: "فيديو",
    photo: "الصور بحجمها الأصلي",
    slideshow: "عرض شرائح (فيديو)",
    gallery: "الصور + عرض الشرائح",
    audioOnly: "الصوت فقط (mp3)",
    subtitles: "الترجمة (⁦.srt⁩)",
    subtitlesAuto: "مُنشأة تلقائيًا",
    back: "رجوع",
    starting: "جارٍ بدء التنزيل…",
    waiting: "في انتظار دورك على الخادم…",
    downloading: "جارٍ التنزيل",
    converting: "جارٍ المعالجة",
    left: (eta) => `المتبقي ${eta}`,
    saving: "جارٍ الحفظ في «التنزيلات»…",
    done: "تم — الملف في «التنزيلات».",
    news: "📣 أخبار المشروع: ⁦@videonerdownload⁩",
    again: "تنزيل فيديو آخر",
    directDownload: "تنزيل الفيديو (mp4)",
    directPhoto: "تنزيل الصورة (jpg)",
    directNote: "مباشرةً من متصفحك — دون انتظار على الخادم",
    moreOptions: "جودات أخرى والصوت",
    fallback: "تعذّر التنزيل من المتصفح — جارٍ التنزيل عبر الخادم.",
    openSite: "فتح videoner.download",
    retry: "حاول مرة أخرى",
    min: "د",
    sec: "ث",
    errNetwork: "تعذّر الاتصال بـ Videoner. تحقّق من اتصالك بالإنترنت وحاول مرة أخرى.",
    errRateLimit: "طلبات كثيرة متتالية. انتظر دقيقة وحاول مرة أخرى.",
    errUnsupported:
      "لا يوجد في هذه الصفحة فيديو يستطيع Videoner تنزيله. افتح صفحة فيديو أو منشور محدّد.",
    errYoutubeDaily: "استُنفد الحد اليومي لـ YouTube على شبكتك. حاول مرة أخرى غدًا.",
    errTooLarge: "الملف كبير جدًا بهذه الجودة. اختر جودة أقل.",
    errLogin:
      "هذا المنشور متاح فقط للمستخدمين الذين سجّلوا الدخول. أما المنشورات العامة فتُنزَّل دون أي مشكلة.",
    errRegion: "قيّد صاحب المنشور مشاهدته حسب الدولة، لذا لا يمكن تنزيله.",
    errServerBlocked: "تقيّد المنصة وصول خادمنا مؤقتًا. يُرجى المحاولة لاحقًا.",
    errFailed: "فشل التنزيل. حاول مرة أخرى أو اختر جودة أخرى.",
    errGeneric: "حدث خطأ ما. يُرجى المحاولة مرة أخرى بعد قليل.",
    acctButton: (p) => `🔑 ربط حسابك على ${p} بالبوت`,
    acctWarn: (p) =>
      `سيتمكّن ⁦@VideonerBot⁩ من تنزيل ما لا يراه إلا المسجّلون على ${p} باستخدام حسابك: القصص والمنشورات الخاصة. لا تحب المنصات التنزيل الآلي وقد تقيّد الحساب — يُفضَّل ربط حساب ثانوي. سيطلب المتصفح إذنًا بقراءة ملفات تعريف الارتباط (الكوكيز) لهذا الموقع؛ ولن يُرسَل إلى الخادم سوى كوكيز ${p}، وهي مشفّرة.`,
    acctConfirm: "ربط",
    acctCancel: "إلغاء",
    acctSending: "جارٍ الربط…",
    acctDenied: "لا يمكن ربط الحساب دون إذن الوصول إلى الكوكيز.",
    acctNoLogin: (p) => `لم تسجّل الدخول إلى ${p} في هذا المتصفح. سجّل الدخول في الموقع ثم حاول مرة أخرى.`,
    acctFailed: "لم ينجح ذلك. حاول مرة أخرى بعد قليل.",
    acctCodeTitle: (p) => `رمز ربط ${p}:`,
    acctCodeHelp:
      "أرسله إلى ⁦@VideonerBot⁩ في محادثة خاصة — لتنزيلاتك الشخصية. أما للمجموعة، فأرسل ⁦/connect الرمز⁩ في المجموعة. الرمز صالح لمدة 10 دقائق.",
    acctCopy: "نسخ",
    acctCopied: "تم النسخ",
    acctOpenBot: "فتح البوت",
    acctNewCode: "الحصول على رمز جديد",
    acctList: "حساباتي المرتبطة في البوت",
    acctRevoke: "إلغاء إذن الوصول إلى الكوكيز",
    acctRevoked:
      "أُلغي إذن الوصول إلى الكوكيز — لم تعد الإضافة تقرؤها. أما الحسابات التي ربطتها من قبل فتبقى في البوت: يمكنك فصلها من «حساباتي المرتبطة في البوت».",
    playlistOffer: "📃 تنزيل قائمة التشغيل كاملة",
    playlistTitle: (title, n) => `📃 قائمة التشغيل${title ? ` «⁨${title}⁩»` : ""}: ${n} فيديو`,
    playlistHint: "سأنزّلها واحدًا تلو الآخر. يمكنك إغلاق هذه النافذة.",
    playlist720: "قائمة التشغيل بدقة 720p",
    playlistBest: "قائمة التشغيل بأفضل جودة",
    playlistAudio: "قائمة التشغيل — الصوت فقط (mp3)",
    playlistProgress: (i, n) => `الفيديو ${i} من ${n}`,
    playlistStats: (done, failed) => `تم التنزيل: ${done}${failed ? ` · فشل: ${failed}` : ""}`,
    playlistStop: "⏹ إيقاف",
    playlistDone: (done, n) => `اكتمل تنزيل قائمة التشغيل: ${done} من ${n}.`,
    playlistStopped: (done, n) => `تم الإيقاف. تم تنزيل ${done} من ${n}.`,
    playlistLoading: "جارٍ جلب قائمة الفيديوهات…",
    close: "إغلاق",
    updateAvailable: (v) => `صدر الإصدار الجديد ${v}.`,
    updateHow: "كيفية التحديث",
    langAuto: "تلقائي",
    langLabel: "اللغة",
  },
  // Упрощённый китайский. Полноширинная пунктуация в предложениях; латиница
  // (названия площадок, @VideonerBot, /connect) — как есть.
  zh: {
    loading: "正在获取视频信息…",
    notVideoPage:
      "请打开 YouTube、TikTok、Instagram、Facebook、X、Vimeo、VK、Rutube、OK.ru、Pinterest 或 Threads 上的视频页面，然后再次点击图标。GetCourse 课程：如果课程页面是在安装扩展之前打开的，请刷新该页面。",
    gcLesson: "GetCourse 课程",
    gcPick: "本课程包含多个视频，请选择一个",
    gcVideo: (n) => `视频 ${n}`,
    gcNote: "由你的浏览器下载并合并视频。可以关闭此窗口，但不要关闭浏览器。",
    gcNoStream: "无法从播放器获取视频。请刷新课程页面后重试。",
    video: "视频",
    photo: "原始尺寸图片",
    slideshow: "幻灯片（视频）",
    gallery: "图片 + 幻灯片",
    audioOnly: "仅音频（mp3）",
    subtitles: "字幕（.srt）",
    subtitlesAuto: "自动生成",
    back: "返回",
    starting: "正在开始下载…",
    waiting: "正在服务器上排队等候…",
    downloading: "正在下载",
    converting: "正在处理",
    left: (eta) => `剩余 ${eta}`,
    saving: "正在保存到“下载”…",
    done: "完成，文件已保存到“下载”。",
    news: "📣 项目动态：@videonerdownload",
    again: "继续下载",
    directDownload: "下载视频（mp4）",
    directPhoto: "下载图片（jpg）",
    directNote: "直接通过浏览器下载，无需服务器排队",
    moreOptions: "其他画质和音频",
    fallback: "浏览器下载失败，正在通过服务器下载。",
    openSite: "打开 videoner.download",
    retry: "重试",
    min: "分钟",
    sec: "秒",
    errNetwork: "无法连接 Videoner。请检查网络连接后重试。",
    errRateLimit: "连续请求过多。请等待一分钟后重试。",
    errUnsupported:
      "此页面上没有 Videoner 可以下载的视频。请打开具体视频或帖子的页面。",
    errYoutubeDaily: "你所在网络的 YouTube 每日限额已用完。请明天再试。",
    errTooLarge: "该画质的文件太大。请选择较低的画质。",
    errLogin:
      "此帖子仅对已登录用户可见。公开帖子可以正常下载。",
    errRegion: "作者按国家/地区限制了此帖子的观看，因此无法下载。",
    errServerBlocked: "该平台暂时限制了我们服务器的访问。请稍后重试。",
    errFailed: "下载失败。请重试或选择其他画质。",
    errGeneric: "出了点问题。请稍后重试。",
    acctButton: (p) => `🔑 将你的 ${p} 账号连接到机器人`,
    acctWarn: (p) =>
      `@VideonerBot 将能使用你的账号下载 ${p} 上仅登录用户可见的内容：快拍（Stories）、私密帖子。各平台不喜欢自动下载，可能会限制账号，建议连接一个非主要账号。浏览器会请求读取此网站 Cookie 的权限；只有 ${p} 的 Cookie 会以加密方式发送到服务器。`,
    acctConfirm: "连接",
    acctCancel: "取消",
    acctSending: "正在连接…",
    acctDenied: "没有 Cookie 权限，无法连接账号。",
    acctNoLogin: (p) => `你尚未在此浏览器中登录 ${p}。请在该网站登录后重试。`,
    acctFailed: "操作未成功。请稍后重试。",
    acctCodeTitle: (p) => `连接 ${p} 的验证码：`,
    acctCodeHelp:
      "在私聊中将其发送给 @VideonerBot，用于你自己的下载。如需用于群组，请在群组中发送 /connect 验证码。验证码 10 分钟内有效。",
    acctCopy: "复制",
    acctCopied: "已复制",
    acctOpenBot: "打开机器人",
    acctNewCode: "获取新验证码",
    acctList: "我在机器人中的连接",
    acctRevoke: "撤销 Cookie 访问权限",
    acctRevoked:
      "已撤销 Cookie 访问权限，扩展不再读取 Cookie。已连接的账号仍保留在机器人中：可在“我在机器人中的连接”中移除。",
    playlistOffer: "📃 下载整个播放列表",
    playlistTitle: (title, n) => `📃 播放列表${title ? `“${title}”` : ""}：${n} 个视频`,
    playlistHint: "将逐个依次下载。可以关闭此窗口。",
    playlist720: "播放列表（720p）",
    playlistBest: "播放列表（最佳画质）",
    playlistAudio: "播放列表 — 仅音频（mp3）",
    playlistProgress: (i, n) => `第 ${i} 个视频，共 ${n} 个`,
    playlistStats: (done, failed) => `已下载：${done}${failed ? ` · 失败：${failed}` : ""}`,
    playlistStop: "⏹ 停止",
    playlistDone: (done, n) => `播放列表下载完成：${done}/${n}。`,
    playlistStopped: (done, n) => `已停止。已下载 ${done}/${n}。`,
    playlistLoading: "正在获取视频列表…",
    close: "关闭",
    updateAvailable: (v) => `新版本 ${v} 已发布。`,
    updateHow: "如何更新",
    langAuto: "自动",
    langLabel: "语言",
  },
  // Хинди (деванагари), современный разговорный язык; устоявшиеся технические
  // заимствования — как есть. Латиница (названия площадок, @VideonerBot,
  // /connect), западные цифры и GB/MB — как в английском.
  hi: {
    loading: "वीडियो की जानकारी ली जा रही है…",
    notVideoPage:
      "YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest या Threads पर किसी वीडियो का पेज खोलें और फिर से आइकन पर क्लिक करें। GetCourse लेसन: अगर लेसन का पेज एक्सटेंशन इंस्टॉल होने से पहले खुला था, तो उसे रीलोड करें।",
    gcLesson: "GetCourse लेसन",
    gcPick: "इस लेसन में कई वीडियो हैं — एक चुनें",
    gcVideo: (n) => `वीडियो ${n}`,
    gcNote: "आपका ब्राउज़र इसे डाउनलोड करके जोड़ता है। आप यह विंडो बंद कर सकते हैं, लेकिन ब्राउज़र नहीं।",
    gcNoStream: "प्लेयर से वीडियो नहीं मिल सका। लेसन का पेज रीलोड करें और फिर से कोशिश करें।",
    video: "वीडियो",
    photo: "ओरिजिनल साइज़ में फ़ोटो",
    slideshow: "स्लाइडशो (वीडियो)",
    gallery: "फ़ोटो + स्लाइडशो",
    audioOnly: "सिर्फ़ ऑडियो (mp3)",
    subtitles: "सबटाइटल (.srt)",
    subtitlesAuto: "अपने-आप बने",
    back: "वापस",
    starting: "डाउनलोड शुरू हो रहा है…",
    waiting: "सर्वर पर खाली जगह का इंतज़ार…",
    downloading: "डाउनलोड हो रहा है",
    converting: "प्रोसेस हो रहा है",
    left: (eta) => `${eta} बाकी`,
    saving: "डाउनलोड्स में सेव हो रहा है…",
    done: "हो गया — फ़ाइल आपके डाउनलोड्स में है।",
    news: "📣 प्रोजेक्ट की खबरें: @videonerdownload",
    again: "एक और डाउनलोड करें",
    directDownload: "वीडियो डाउनलोड करें (mp4)",
    directPhoto: "फ़ोटो डाउनलोड करें (jpg)",
    directNote: "सीधे आपके ब्राउज़र से — सर्वर की कतार के बिना",
    moreOptions: "दूसरी क्वालिटी और ऑडियो",
    fallback: "ब्राउज़र से डाउनलोड नहीं हो सका — सर्वर के ज़रिए डाउनलोड हो रहा है।",
    openSite: "videoner.download खोलें",
    retry: "फिर से कोशिश करें",
    min: "मिनट",
    sec: "सेकंड",
    errNetwork: "Videoner से कनेक्ट नहीं हो पा रहा। अपना इंटरनेट कनेक्शन जाँचें और फिर से कोशिश करें।",
    errRateLimit: "लगातार बहुत ज़्यादा रिक्वेस्ट। एक मिनट रुकें और फिर से कोशिश करें।",
    errUnsupported:
      "इस पेज पर ऐसा कोई वीडियो नहीं है जिसे Videoner डाउनलोड कर सके। किसी खास वीडियो या पोस्ट का पेज खोलें।",
    errYoutubeDaily: "आपके नेटवर्क के लिए YouTube की आज की लिमिट खत्म हो गई है। कल फिर से कोशिश करें।",
    errTooLarge: "इस क्वालिटी में फ़ाइल बहुत बड़ी है। कम क्वालिटी चुनें।",
    errLogin:
      "यह पोस्ट सिर्फ़ साइन-इन किए हुए यूज़र्स के लिए उपलब्ध है। पब्लिक पोस्ट बिना किसी दिक्कत के डाउनलोड होते हैं।",
    errRegion: "लेखक ने इस पोस्ट को देश के हिसाब से सीमित किया है, इसलिए इसे डाउनलोड नहीं किया जा सकता।",
    errServerBlocked: "प्लेटफ़ॉर्म फ़िलहाल हमारे सर्वर को सीमित कर रहा है। कृपया थोड़ी देर बाद फिर से कोशिश करें।",
    errFailed: "डाउनलोड नहीं हो सका। फिर से कोशिश करें या कोई दूसरी क्वालिटी चुनें।",
    errGeneric: "कुछ गड़बड़ हो गई। कृपया थोड़ी देर बाद फिर से कोशिश करें।",
    acctButton: (p) => `🔑 अपना ${p} खाता बॉट से कनेक्ट करें`,
    acctWarn: (p) =>
      `@VideonerBot आपके खाते से ${p} पर वह कंटेंट डाउनलोड कर पाएगा जो सिर्फ़ साइन-इन किए हुए लोगों को दिखता है: स्टोरीज़, प्राइवेट पोस्ट। प्लेटफ़ॉर्म ऑटोमैटिक डाउनलोड पसंद नहीं करते और खाते पर रोक लगा सकते हैं — बेहतर है कोई दूसरा, अतिरिक्त खाता कनेक्ट करें। ब्राउज़र इस साइट की कुकीज़ पढ़ने की अनुमति माँगेगा; सर्वर पर सिर्फ़ ${p} की कुकीज़ एन्क्रिप्ट होकर जाती हैं।`,
    acctConfirm: "कनेक्ट करें",
    acctCancel: "रद्द करें",
    acctSending: "कनेक्ट हो रहा है…",
    acctDenied: "कुकीज़ की अनुमति के बिना खाता कनेक्ट नहीं किया जा सकता।",
    acctNoLogin: (p) => `इस ब्राउज़र में आप ${p} पर साइन इन नहीं हैं। साइट पर साइन इन करें और फिर से कोशिश करें।`,
    acctFailed: "यह नहीं हो सका। थोड़ी देर बाद फिर से कोशिश करें।",
    acctCodeTitle: (p) => `${p} कनेक्ट करने का कोड:`,
    acctCodeHelp:
      "इसे प्राइवेट चैट में @VideonerBot को भेजें — अपने डाउनलोड के लिए। ग्रुप के लिए, ग्रुप में /connect कोड भेजें। कोड 10 मिनट तक मान्य है।",
    acctCopy: "कॉपी करें",
    acctCopied: "कॉपी हो गया",
    acctOpenBot: "बॉट खोलें",
    acctNewCode: "नया कोड पाएँ",
    acctList: "बॉट में मेरे कनेक्शन",
    acctRevoke: "कुकीज़ की अनुमति वापस लें",
    acctRevoked:
      "कुकीज़ की अनुमति वापस ले ली गई — एक्सटेंशन अब उन्हें नहीं पढ़ता। जो खाते आप पहले कनेक्ट कर चुके हैं, वे बॉट में बने रहेंगे: उन्हें “बॉट में मेरे कनेक्शन” में हटाएँ।",
    playlistOffer: "📃 पूरी प्लेलिस्ट डाउनलोड करें",
    playlistTitle: (title, n) => `📃 प्लेलिस्ट${title ? ` "${title}"` : ""}: ${n} वीडियो`,
    playlistHint: "मैं इन्हें एक-एक करके डाउनलोड करूँगा। आप यह विंडो बंद कर सकते हैं।",
    playlist720: "प्लेलिस्ट 720p में",
    playlistBest: "प्लेलिस्ट सबसे अच्छी क्वालिटी में",
    playlistAudio: "प्लेलिस्ट — सिर्फ़ ऑडियो (mp3)",
    playlistProgress: (i, n) => `वीडियो ${i} / ${n}`,
    playlistStats: (done, failed) => `डाउनलोड हुए: ${done}${failed ? ` · नहीं हो सके: ${failed}` : ""}`,
    playlistStop: "⏹ रोकें",
    playlistDone: (done, n) => `प्लेलिस्ट डाउनलोड हो गई: ${n} में से ${done}।`,
    playlistStopped: (done, n) => `रोक दिया गया। ${n} में से ${done} डाउनलोड हुए।`,
    playlistLoading: "वीडियो की सूची ली जा रही है…",
    close: "बंद करें",
    updateAvailable: (v) => `वर्शन ${v} आ गया है।`,
    updateHow: "अपडेट कैसे करें",
    langAuto: "ऑटो",
    langLabel: "भाषा",
  },
  id: {
    loading: "Mengambil info video…",
    notVideoPage:
      "Buka halaman video di YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest atau Threads, lalu klik ikonnya lagi. Pelajaran GetCourse: jika halaman pelajaran sudah terbuka sebelum ekstensi dipasang, muat ulang halaman tersebut.",
    gcLesson: "Pelajaran GetCourse",
    gcPick: "Pelajaran ini berisi beberapa video — pilih salah satu",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Browser Anda yang mengunduh dan menggabungkannya. Jendela ini boleh ditutup, tetapi browser jangan.",
    gcNoStream: "Gagal mengambil video dari pemutar. Muat ulang halaman pelajaran dan coba lagi.",
    video: "Video",
    photo: "Foto ukuran asli",
    slideshow: "Tayangan slide (video)",
    gallery: "Foto + tayangan slide",
    audioOnly: "Hanya audio (mp3)",
    subtitles: "Subtitel (.srt)",
    subtitlesAuto: "otomatis",
    back: "Kembali",
    starting: "Memulai unduhan…",
    waiting: "Menunggu giliran di server…",
    downloading: "Mengunduh",
    converting: "Memproses",
    left: (eta) => `sisa ${eta}`,
    saving: "Menyimpan ke Unduhan…",
    done: "Selesai — file ada di folder Unduhan Anda.",
    news: "📣 Berita proyek: @videonerdownload",
    again: "Unduh yang lain",
    directDownload: "Unduh video (mp4)",
    directPhoto: "Unduh foto (jpg)",
    directNote: "Langsung dari browser Anda — tanpa antrean server",
    moreOptions: "Kualitas lain dan audio",
    fallback: "Unduhan lewat browser gagal — mengunduh lewat server.",
    openSite: "Buka videoner.download",
    retry: "Coba lagi",
    min: "mnt",
    sec: "dtk",
    errNetwork: "Tidak dapat terhubung ke Videoner. Periksa koneksi internet Anda dan coba lagi.",
    errRateLimit: "Terlalu banyak permintaan berturut-turut. Tunggu sebentar lalu coba lagi.",
    errUnsupported:
      "Tidak ada video di halaman ini yang bisa diunduh Videoner. Buka halaman video atau postingan tertentu.",
    errYoutubeDaily: "Batas harian YouTube untuk jaringan Anda sudah habis. Coba lagi besok.",
    errTooLarge: "File dalam kualitas ini terlalu besar. Pilih kualitas yang lebih rendah.",
    errLogin:
      "Postingan ini hanya tersedia bagi pengguna yang sudah masuk. Postingan publik bisa diunduh tanpa masalah.",
    errRegion: "Pembuat membatasi postingan ini berdasarkan negara, jadi tidak bisa diunduh.",
    errServerBlocked: "Platform untuk sementara membatasi akses server kami. Silakan coba lagi nanti.",
    errFailed: "Unduhan gagal. Coba lagi atau pilih kualitas lain.",
    errGeneric: "Terjadi kesalahan. Silakan coba lagi beberapa saat lagi.",
    acctButton: (p) => `🔑 Hubungkan akun ${p} Anda ke bot`,
    acctWarn: (p) =>
      `@VideonerBot akan bisa mengunduh dengan akun ${p} Anda konten yang hanya terlihat oleh pengguna yang sudah masuk: story, postingan privat. Platform tidak menyukai unduhan otomatis dan bisa membatasi akun — sebaiknya hubungkan akun cadangan. Browser akan meminta izin untuk membaca cookie situs ini; hanya cookie ${p} yang dikirim ke server, dalam bentuk terenkripsi.`,
    acctConfirm: "Hubungkan",
    acctCancel: "Batal",
    acctSending: "Menghubungkan…",
    acctDenied: "Akun tidak bisa dihubungkan tanpa izin cookie.",
    acctNoLogin: (p) => `Anda belum masuk ke ${p} di browser ini. Masuk di situsnya lalu coba lagi.`,
    acctFailed: "Tidak berhasil. Coba lagi beberapa saat lagi.",
    acctCodeTitle: (p) => `Kode untuk menghubungkan ${p}:`,
    acctCodeHelp:
      "Kirim kode ini ke @VideonerBot lewat chat pribadi — untuk unduhan Anda sendiri. Untuk grup, kirim /connect KODE di grup tersebut. Kode berlaku 10 menit.",
    acctCopy: "Salin",
    acctCopied: "Tersalin",
    acctOpenBot: "Buka bot",
    acctNewCode: "Dapatkan kode baru",
    acctList: "Koneksi saya di bot",
    acctRevoke: "Cabut akses cookie",
    acctRevoked:
      "Akses cookie sudah dicabut — ekstensi tidak lagi membacanya. Akun yang sudah terhubung tetap ada di bot: putuskan di “Koneksi saya di bot”.",
    playlistOffer: "📃 Unduh seluruh playlist",
    playlistTitle: (title, n) => `📃 Playlist${title ? ` "${title}"` : ""}: ${n} video`,
    playlistHint: "Video akan diunduh satu per satu secara berurutan. Jendela ini boleh ditutup.",
    playlist720: "Playlist dalam 720p",
    playlistBest: "Playlist dalam kualitas terbaik",
    playlistAudio: "Playlist — hanya audio (mp3)",
    playlistProgress: (i, n) => `Video ${i} dari ${n}`,
    playlistStats: (done, failed) => `Terunduh: ${done}${failed ? ` · gagal: ${failed}` : ""}`,
    playlistStop: "⏹ Hentikan",
    playlistDone: (done, n) => `Playlist terunduh: ${done} dari ${n}.`,
    playlistStopped: (done, n) => `Dihentikan. Terunduh ${done} dari ${n}.`,
    playlistLoading: "Mengambil daftar video…",
    close: "Tutup",
    updateAvailable: (v) => `Versi ${v} sudah tersedia.`,
    updateHow: "Cara memperbarui",
    langAuto: "Otomatis",
    langLabel: "Bahasa",
  },
  sw: {
    loading: "Inapata maelezo ya video…",
    notVideoPage:
      "Fungua ukurasa wa video kwenye YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest au Threads, kisha bofya ikoni tena. Somo la GetCourse: ikiwa ukurasa wa somo ulikuwa wazi kabla kiendelezi hakijasakinishwa, upakie upya.",
    gcLesson: "Somo la GetCourse",
    gcPick: "Somo hili lina video kadhaa — chagua moja",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Kivinjari chako ndicho kinachoipakua na kuiunganisha. Unaweza kufunga dirisha hili, lakini si kivinjari.",
    gcNoStream: "Imeshindwa kupata video kutoka kwenye kicheza. Pakia upya ukurasa wa somo kisha ujaribu tena.",
    video: "Video",
    photo: "Picha za ukubwa halisi",
    slideshow: "Onyesho la slaidi (video)",
    gallery: "Picha + onyesho la slaidi",
    audioOnly: "Sauti pekee (mp3)",
    subtitles: "Manukuu (.srt)",
    subtitlesAuto: "ya kiotomatiki",
    back: "Rudi",
    starting: "Inaanza kupakua…",
    waiting: "Inasubiri nafasi kwenye seva…",
    downloading: "Inapakua",
    converting: "Inachakata",
    left: (eta) => `zimebaki ${eta}`,
    saving: "Inahifadhi kwenye Vipakuliwa…",
    done: "Imekamilika — faili iko kwenye Vipakuliwa vyako.",
    news: "📣 Habari za mradi: @videonerdownload",
    again: "Pakua nyingine",
    directDownload: "Pakua video (mp4)",
    directPhoto: "Pakua picha (jpg)",
    directNote: "Moja kwa moja kutoka kwenye kivinjari chako — bila foleni ya seva",
    moreOptions: "Ubora mwingine na sauti",
    fallback: "Kupakua kupitia kivinjari kumeshindwa — inapakua kupitia seva.",
    openSite: "Fungua videoner.download",
    retry: "Jaribu tena",
    min: "dak",
    sec: "sek",
    errNetwork: "Imeshindwa kuunganisha na Videoner. Angalia muunganisho wako wa intaneti kisha ujaribu tena.",
    errRateLimit: "Maombi mengi mno mfululizo. Subiri kidogo kisha ujaribu tena.",
    errUnsupported:
      "Hakuna video kwenye ukurasa huu ambayo Videoner inaweza kupakua. Fungua ukurasa wa video au chapisho mahususi.",
    errYoutubeDaily: "Kikomo cha kila siku cha YouTube kwa mtandao wako kimeisha. Jaribu tena kesho.",
    errTooLarge: "Faili ni kubwa mno kwa ubora huu. Chagua ubora wa chini zaidi.",
    errLogin:
      "Chapisho hili linapatikana tu kwa watumiaji walioingia. Machapisho ya umma yanapakuliwa bila tatizo lolote.",
    errRegion: "Mwandishi amezuia chapisho hili kulingana na nchi, kwa hiyo haliwezi kupakuliwa.",
    errServerBlocked: "Jukwaa linazuia seva yetu kwa muda. Tafadhali jaribu tena baadaye.",
    errFailed: "Kupakua kumeshindwa. Jaribu tena au chagua ubora mwingine.",
    errGeneric: "Hitilafu imetokea. Tafadhali jaribu tena baada ya muda mfupi.",
    acctButton: (p) => `🔑 Unganisha akaunti yako ya ${p} na bot`,
    acctWarn: (p) =>
      `@VideonerBot itaweza kupakua kwa kutumia akaunti yako ya ${p} maudhui yanayoonekana tu kwa watumiaji walioingia: stories, machapisho ya faragha. Majukwaa hayapendi upakuaji wa kiotomatiki na yanaweza kuzuia akaunti — ni bora kuunganisha akaunti ya ziada. Kivinjari kitaomba ruhusa ya kusoma cookies za tovuti hii; cookies za ${p} pekee ndizo hutumwa kwa seva, zikiwa zimesimbwa.`,
    acctConfirm: "Unganisha",
    acctCancel: "Ghairi",
    acctSending: "Inaunganisha…",
    acctDenied: "Akaunti haiwezi kuunganishwa bila ruhusa ya cookies.",
    acctNoLogin: (p) => `Hujaingia kwenye ${p} katika kivinjari hiki. Ingia kwenye tovuti kisha ujaribu tena.`,
    acctFailed: "Imeshindikana. Jaribu tena baada ya muda mfupi.",
    acctCodeTitle: (p) => `Msimbo wa kuunganisha ${p}:`,
    acctCodeHelp:
      "Utume kwa @VideonerBot kwenye gumzo la faragha — kwa vipakuliwa vyako mwenyewe. Kwa kikundi, tuma /connect MSIMBO ndani ya kikundi hicho. Msimbo ni halali kwa dakika 10.",
    acctCopy: "Nakili",
    acctCopied: "Imenakiliwa",
    acctOpenBot: "Fungua bot",
    acctNewCode: "Pata msimbo mpya",
    acctList: "Miunganisho yangu kwenye bot",
    acctRevoke: "Ondoa ruhusa ya cookies",
    acctRevoked:
      "Ruhusa ya cookies imeondolewa — kiendelezi hakizisomi tena. Akaunti ulizokwisha kuunganisha zinabaki kwenye bot: ziondoe katika “Miunganisho yangu kwenye bot”.",
    playlistOffer: "📃 Pakua orodha nzima ya kucheza",
    playlistTitle: (title, n) => `📃 Orodha ya kucheza${title ? ` "${title}"` : ""}: video ${n}`,
    playlistHint: "Nitazipakua moja baada ya nyingine. Unaweza kufunga dirisha hili.",
    playlist720: "Orodha ya kucheza katika 720p",
    playlistBest: "Orodha ya kucheza katika ubora bora zaidi",
    playlistAudio: "Orodha ya kucheza — sauti pekee (mp3)",
    playlistProgress: (i, n) => `Video ${i} kati ya ${n}`,
    playlistStats: (done, failed) => `Zimepakuliwa: ${done}${failed ? ` · zimeshindwa: ${failed}` : ""}`,
    playlistStop: "⏹ Simamisha",
    playlistDone: (done, n) => `Orodha ya kucheza imepakuliwa: ${done} kati ya ${n}.`,
    playlistStopped: (done, n) => `Imesimamishwa. Zimepakuliwa ${done} kati ya ${n}.`,
    playlistLoading: "Inapata orodha ya video…",
    close: "Funga",
    updateAvailable: (v) => `Toleo ${v} limetoka.`,
    updateHow: "Jinsi ya kusasisha",
    langAuto: "Otomatiki",
    langLabel: "Lugha",
  },
  de: {
    loading: "Lade Video-Infos…",
    notVideoPage:
      "Öffne eine Videoseite auf YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest oder Threads und klick erneut auf das Symbol. GetCourse-Lektion: War die Seite schon vor der Installation der Erweiterung offen, lade sie neu.",
    gcLesson: "GetCourse-Lektion",
    gcPick: "Die Lektion hat mehrere Videos — wähl eins aus",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Dein Browser lädt und fügt es zusammen. Das Fenster darfst du schließen, den Browser nicht.",
    gcNoStream: "Video konnte nicht aus dem Player geholt werden. Lade die Lektion neu und versuch es noch mal.",
    video: "Video",
    photo: "Fotos in Originalgröße",
    slideshow: "Diashow (Video)",
    gallery: "Fotos + Diashow",
    audioOnly: "Nur Audio (mp3)",
    subtitles: "Untertitel (.srt)",
    subtitlesAuto: "automatisch",
    back: "Zurück",
    starting: "Starte den Download…",
    waiting: "Warte auf einen freien Platz auf dem Server…",
    downloading: "Lade herunter",
    converting: "Verarbeite",
    left: (eta) => `noch ${eta}`,
    saving: "Speichere in „Downloads“…",
    done: "Fertig — die Datei liegt in „Downloads“.",
    news: "📣 Projekt-News: @videonerdownload",
    again: "Noch eins laden",
    directDownload: "Video laden (mp4)",
    directPhoto: "Foto laden (jpg)",
    directNote: "Direkt aus dem Browser — ohne Server-Warteschlange",
    moreOptions: "Andere Qualitäten und Audio",
    fallback: "Im Browser hat's nicht geklappt — lade über den Server.",
    openSite: "videoner.download öffnen",
    retry: "Noch mal versuchen",
    min: "Min.",
    sec: "s",
    errNetwork: "Keine Verbindung zu Videoner. Prüf dein Internet und versuch es noch mal.",
    errRateLimit: "Zu viele Anfragen hintereinander. Warte eine Minute und versuch es noch mal.",
    errUnsupported:
      "Auf dieser Seite gibt es kein Video, das Videoner laden kann. Öffne die Seite eines bestimmten Videos oder Posts.",
    errYoutubeDaily: "Das tägliche YouTube-Limit für dein Netzwerk ist aufgebraucht. Versuch es morgen.",
    errTooLarge: "Die Datei ist in dieser Qualität zu groß. Wähl eine niedrigere.",
    errLogin:
      "Dieser Beitrag ist nur für angemeldete Nutzer sichtbar. Öffentliche Beiträge lassen sich problemlos laden.",
    errRegion: "Der Autor hat den Beitrag auf bestimmte Länder beschränkt — er lässt sich nicht laden.",
    errServerBlocked: "Die Plattform schränkt unseren Server gerade ein. Versuch es später noch mal.",
    errFailed: "Download fehlgeschlagen. Versuch es noch mal oder wähl eine andere Qualität.",
    errGeneric: "Etwas ist schiefgelaufen. Versuch es etwas später noch mal.",
    acctButton: (p) => `🔑 Dein ${p}-Konto mit dem Bot verbinden`,
    acctWarn: (p) =>
      `@VideonerBot kann dann über dein ${p}-Konto laden, was nur Angemeldete sehen: Storys, private Beiträge. Plattformen mögen keine automatischen Downloads und können das Konto einschränken — verbinde lieber ein Zweitkonto. Der Browser fragt nach der Erlaubnis für die Cookies dieser Seite; an den Server gehen nur die ${p}-Cookies, verschlüsselt.`,
    acctConfirm: "Verbinden",
    acctCancel: "Abbrechen",
    acctSending: "Verbinde…",
    acctDenied: "Ohne Cookie-Erlaubnis lässt sich das Konto nicht verbinden.",
    acctNoLogin: (p) => `Du bist in diesem Browser nicht bei ${p} angemeldet. Melde dich auf der Seite an und versuch es noch mal.`,
    acctFailed: "Hat nicht geklappt. Versuch es etwas später noch mal.",
    acctCodeTitle: (p) => `Code zum Verbinden von ${p}:`,
    acctCodeHelp:
      "Schick ihn @VideonerBot im Privatchat — für deine eigenen Downloads. Für eine Gruppe schick dort /connect CODE. Der Code gilt 10 Minuten.",
    acctCopy: "Kopieren",
    acctCopied: "Kopiert",
    acctOpenBot: "Bot öffnen",
    acctNewCode: "Neuen Code holen",
    acctList: "Meine Verbindungen im Bot",
    acctRevoke: "Cookie-Zugriff entziehen",
    acctRevoked:
      "Cookie-Zugriff entzogen — die Erweiterung liest sie nicht mehr. Schon verbundene Konten bleiben im Bot: trennen kannst du sie unter „Meine Verbindungen im Bot“.",
    playlistOffer: "📃 Ganze Playlist laden",
    playlistTitle: (title, n) => `📃 Playlist${title ? ` „${title}“` : ""}: ${n} Videos`,
    playlistHint: "Ich lade sie nacheinander. Das Fenster darfst du schließen.",
    playlist720: "Playlist in 720p",
    playlistBest: "Playlist in bester Qualität",
    playlistAudio: "Playlist — nur Audio (mp3)",
    playlistProgress: (i, n) => `Video ${i} von ${n}`,
    playlistStats: (done, failed) => `Geladen: ${done}${failed ? ` · fehlgeschlagen: ${failed}` : ""}`,
    playlistStop: "⏹ Stoppen",
    playlistDone: (done, n) => `Playlist geladen: ${done} von ${n}.`,
    playlistStopped: (done, n) => `Gestoppt. Geladen: ${done} von ${n}.`,
    playlistLoading: "Hole die Videoliste…",
    close: "Schließen",
    updateAvailable: (v) => `Version ${v} ist da.`,
    updateHow: "So aktualisierst du",
    langAuto: "Auto",
    langLabel: "Sprache",
  },
  fr: {
    loading: "Récupération des infos de la vidéo…",
    notVideoPage:
      "Ouvrez la page d’une vidéo sur YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest ou Threads et cliquez à nouveau sur l’icône. Leçon GetCourse : si la page était ouverte avant l’installation de l’extension, rechargez-la.",
    gcLesson: "Leçon GetCourse",
    gcPick: "Cette leçon contient plusieurs vidéos — choisissez-en une",
    gcVideo: (n) => `Vidéo ${n}`,
    gcNote: "Votre navigateur la télécharge et l’assemble. Vous pouvez fermer cette fenêtre, mais pas le navigateur.",
    gcNoStream: "Impossible de récupérer la vidéo depuis le lecteur. Rechargez la leçon et réessayez.",
    video: "Vidéo",
    photo: "Photos en taille originale",
    slideshow: "Diaporama (vidéo)",
    gallery: "Photos + diaporama",
    audioOnly: "Audio seul (mp3)",
    subtitles: "Sous-titres (.srt)",
    subtitlesAuto: "automatiques",
    back: "Retour",
    starting: "Lancement du téléchargement…",
    waiting: "En attente d’une place libre sur le serveur…",
    downloading: "Téléchargement",
    converting: "Traitement",
    left: (eta) => `encore ${eta}`,
    saving: "Enregistrement dans « Téléchargements »…",
    done: "Terminé — le fichier est dans « Téléchargements ».",
    news: "📣 Actus du projet : @videonerdownload",
    again: "En télécharger une autre",
    directDownload: "Télécharger la vidéo (mp4)",
    directPhoto: "Télécharger la photo (jpg)",
    directNote: "Directement depuis le navigateur — sans file d’attente",
    moreOptions: "Autres qualités et audio",
    fallback: "Échec dans le navigateur — téléchargement via le serveur.",
    openSite: "Ouvrir videoner.download",
    retry: "Réessayer",
    min: "min",
    sec: "s",
    errNetwork: "Impossible de joindre Videoner. Vérifiez votre connexion et réessayez.",
    errRateLimit: "Trop de requêtes d’affilée. Attendez une minute et réessayez.",
    errUnsupported:
      "Aucune vidéo téléchargeable par Videoner sur cette page. Ouvrez la page d’une vidéo ou d’une publication précise.",
    errYoutubeDaily: "La limite quotidienne YouTube de votre réseau est atteinte. Réessayez demain.",
    errTooLarge: "Le fichier est trop lourd dans cette qualité. Choisissez-en une plus basse.",
    errLogin:
      "Cette publication n’est visible que par les utilisateurs connectés. Les publications publiques se téléchargent sans problème.",
    errRegion: "L’auteur a limité cette publication à certains pays — impossible de la télécharger.",
    errServerBlocked: "La plateforme limite temporairement notre serveur. Réessayez plus tard.",
    errFailed: "Le téléchargement a échoué. Réessayez ou choisissez une autre qualité.",
    errGeneric: "Une erreur s’est produite. Réessayez un peu plus tard.",
    acctButton: (p) => `🔑 Connecter votre compte ${p} au bot`,
    acctWarn: (p) =>
      `@VideonerBot pourra télécharger via votre compte ${p} ce que seuls les utilisateurs connectés voient : stories, publications privées. Les plateformes n’aiment pas les téléchargements automatiques et peuvent restreindre le compte — connectez plutôt un compte secondaire. Le navigateur demandera l’autorisation de lire les cookies de ce site ; seuls les cookies ${p} sont envoyés au serveur, chiffrés.`,
    acctConfirm: "Connecter",
    acctCancel: "Annuler",
    acctSending: "Connexion…",
    acctDenied: "Impossible de connecter le compte sans l’autorisation d’accès aux cookies.",
    acctNoLogin: (p) => `Vous n’êtes pas connecté à ${p} dans ce navigateur. Connectez-vous sur le site et réessayez.`,
    acctFailed: "Cela n’a pas marché. Réessayez un peu plus tard.",
    acctCodeTitle: (p) => `Code pour connecter ${p} :`,
    acctCodeHelp:
      "Envoyez-le à @VideonerBot en message privé — pour vos propres téléchargements. Pour un groupe, envoyez /connect CODE dans le groupe. Le code est valable 10 minutes.",
    acctCopy: "Copier",
    acctCopied: "Copié",
    acctOpenBot: "Ouvrir le bot",
    acctNewCode: "Obtenir un nouveau code",
    acctList: "Mes connexions dans le bot",
    acctRevoke: "Retirer l’accès aux cookies",
    acctRevoked:
      "Accès aux cookies retiré — l’extension ne les lit plus. Les comptes déjà connectés restent dans le bot : déconnectez-les dans « Mes connexions dans le bot ».",
    playlistOffer: "📃 Télécharger toute la playlist",
    playlistTitle: (title, n) => `📃 Playlist${title ? ` « ${title} »` : ""} : ${n} vidéos`,
    playlistHint: "Je les télécharge une par une. Vous pouvez fermer cette fenêtre.",
    playlist720: "Playlist en 720p",
    playlistBest: "Playlist en meilleure qualité",
    playlistAudio: "Playlist — audio seul (mp3)",
    playlistProgress: (i, n) => `Vidéo ${i} sur ${n}`,
    playlistStats: (done, failed) => `Téléchargées : ${done}${failed ? ` · échecs : ${failed}` : ""}`,
    playlistStop: "⏹ Arrêter",
    playlistDone: (done, n) => `Playlist téléchargée : ${done} sur ${n}.`,
    playlistStopped: (done, n) => `Arrêté. Téléchargées : ${done} sur ${n}.`,
    playlistLoading: "Récupération de la liste des vidéos…",
    close: "Fermer",
    updateAvailable: (v) => `La version ${v} est disponible.`,
    updateHow: "Comment mettre à jour",
    langAuto: "Auto",
    langLabel: "Langue",
  },
  it: {
    loading: "Recupero le info del video…",
    notVideoPage:
      "Apri la pagina di un video su YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest o Threads e clicca di nuovo sull’icona. Lezione GetCourse: se la pagina era aperta prima dell’installazione dell’estensione, ricaricala.",
    gcLesson: "Lezione GetCourse",
    gcPick: "Questa lezione ha più video — scegline uno",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Il browser lo scarica e lo assembla. Puoi chiudere questa finestra, ma non il browser.",
    gcNoStream: "Impossibile ottenere il video dal player. Ricarica la lezione e riprova.",
    video: "Video",
    photo: "Foto in dimensioni originali",
    slideshow: "Slideshow (video)",
    gallery: "Foto + slideshow",
    audioOnly: "Solo audio (mp3)",
    subtitles: "Sottotitoli (.srt)",
    subtitlesAuto: "automatici",
    back: "Indietro",
    starting: "Avvio del download…",
    waiting: "In attesa di un posto libero sul server…",
    downloading: "Download",
    converting: "Elaborazione",
    left: (eta) => `ancora ${eta}`,
    saving: "Salvataggio in «Download»…",
    done: "Fatto — il file è in «Download».",
    news: "📣 Novità del progetto: @videonerdownload",
    again: "Scaricane un altro",
    directDownload: "Scarica il video (mp4)",
    directPhoto: "Scarica la foto (jpg)",
    directNote: "Direttamente dal browser — senza coda",
    moreOptions: "Altre qualità e audio",
    fallback: "Download nel browser non riuscito — scarico tramite il server.",
    openSite: "Apri videoner.download",
    retry: "Riprova",
    min: "min",
    sec: "s",
    errNetwork: "Impossibile raggiungere Videoner. Controlla la connessione e riprova.",
    errRateLimit: "Troppe richieste di fila. Aspetta un minuto e riprova.",
    errUnsupported:
      "In questa pagina non c’è nessun video che Videoner possa scaricare. Apri la pagina di un video o di un post specifico.",
    errYoutubeDaily: "Il limite giornaliero di YouTube per la tua rete è esaurito. Riprova domani.",
    errTooLarge: "Il file è troppo grande in questa qualità. Scegline una più bassa.",
    errLogin:
      "Questo post è visibile solo agli utenti che hanno effettuato l’accesso. I post pubblici si scaricano senza problemi.",
    errRegion: "L’autore ha limitato questo post ad alcuni paesi, quindi non si può scaricare.",
    errServerBlocked: "La piattaforma sta limitando temporaneamente il nostro server. Riprova più tardi.",
    errFailed: "Download non riuscito. Riprova o scegli un’altra qualità.",
    errGeneric: "Qualcosa è andato storto. Riprova tra un po’.",
    acctButton: (p) => `🔑 Collega il tuo account ${p} al bot`,
    acctWarn: (p) =>
      `@VideonerBot potrà scaricare con il tuo account ${p} ciò che vedono solo gli utenti che hanno effettuato l’accesso: storie, post privati. Le piattaforme non amano i download automatici e possono limitare l’account — meglio collegarne uno secondario. Il browser chiederà il permesso di leggere i cookie di questo sito; al server vengono inviati solo i cookie di ${p}, cifrati.`,
    acctConfirm: "Collega",
    acctCancel: "Annulla",
    acctSending: "Collegamento…",
    acctDenied: "Non è possibile collegare l’account senza il permesso di accesso ai cookie.",
    acctNoLogin: (p) => `Non hai effettuato l’accesso a ${p} in questo browser. Accedi al sito e riprova.`,
    acctFailed: "Non ha funzionato. Riprova tra un po’.",
    acctCodeTitle: (p) => `Codice per collegare ${p}:`,
    acctCodeHelp:
      "Invialo a @VideonerBot in chat privata — per i tuoi download. Per un gruppo, invia /connect CODE nel gruppo. Il codice è valido 10 minuti.",
    acctCopy: "Copia",
    acctCopied: "Copiato",
    acctOpenBot: "Apri il bot",
    acctNewCode: "Ottieni un nuovo codice",
    acctList: "I miei collegamenti nel bot",
    acctRevoke: "Revoca l’accesso ai cookie",
    acctRevoked:
      "Accesso ai cookie revocato — l’estensione non li legge più. Gli account già collegati restano nel bot: scollegali in «I miei collegamenti nel bot».",
    playlistOffer: "📃 Scarica tutta la playlist",
    playlistTitle: (title, n) => `📃 Playlist${title ? ` «${title}»` : ""}: ${n} video`,
    playlistHint: "Li scarico uno alla volta. Puoi chiudere questa finestra.",
    playlist720: "Playlist in 720p",
    playlistBest: "Playlist nella qualità migliore",
    playlistAudio: "Playlist — solo audio (mp3)",
    playlistProgress: (i, n) => `Video ${i} di ${n}`,
    playlistStats: (done, failed) => `Scaricati: ${done}${failed ? ` · non riusciti: ${failed}` : ""}`,
    playlistStop: "⏹ Interrompi",
    playlistDone: (done, n) => `Playlist scaricata: ${done} di ${n}.`,
    playlistStopped: (done, n) => `Interrotto. Scaricati: ${done} di ${n}.`,
    playlistLoading: "Recupero l’elenco dei video…",
    close: "Chiudi",
    updateAvailable: (v) => `È disponibile la versione ${v}.`,
    updateHow: "Come aggiornare",
    langAuto: "Auto",
    langLabel: "Lingua",
  },
  pt: {
    loading: "Buscando informações do vídeo…",
    notVideoPage:
      "Abra a página de um vídeo no YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest ou Threads e clique no ícone de novo. Aula do GetCourse: se a página da aula estava aberta antes de instalar a extensão, recarregue-a.",
    gcLesson: "Aula do GetCourse",
    gcPick: "Esta aula tem vários vídeos — escolha um",
    gcVideo: (n) => `Vídeo ${n}`,
    gcNote: "Seu navegador baixa e junta o vídeo. Você pode fechar esta janela, mas não o navegador.",
    gcNoStream: "Não foi possível obter o vídeo do player. Recarregue a aula e tente de novo.",
    video: "Vídeo",
    photo: "Fotos em tamanho original",
    slideshow: "Slideshow (vídeo)",
    gallery: "Fotos + slideshow",
    audioOnly: "Só áudio (mp3)",
    subtitles: "Legendas (.srt)",
    subtitlesAuto: "automáticas",
    back: "Voltar",
    starting: "Iniciando o download…",
    waiting: "Aguardando uma vaga no servidor…",
    downloading: "Baixando",
    converting: "Processando",
    left: (eta) => `faltam ${eta}`,
    saving: "Salvando em Downloads…",
    done: "Pronto — o arquivo está em Downloads.",
    news: "📣 Novidades do projeto: @videonerdownload",
    again: "Baixar outro",
    directDownload: "Baixar vídeo (mp4)",
    directPhoto: "Baixar foto (jpg)",
    directNote: "Direto do navegador — sem fila no servidor",
    moreOptions: "Outras qualidades e áudio",
    fallback: "O download pelo navegador falhou — baixando pelo servidor.",
    openSite: "Abrir videoner.download",
    retry: "Tentar de novo",
    min: "min",
    sec: "s",
    errNetwork: "Não foi possível acessar o Videoner. Verifique sua conexão e tente de novo.",
    errRateLimit: "Muitas solicitações seguidas. Espere um minuto e tente de novo.",
    errUnsupported:
      "Não há nesta página nenhum vídeo que o Videoner consiga baixar. Abra a página de um vídeo ou post específico.",
    errYoutubeDaily: "O limite diário do YouTube para sua rede acabou. Tente de novo amanhã.",
    errTooLarge: "O arquivo é grande demais nesta qualidade. Escolha uma menor.",
    errLogin:
      "Este post só está disponível para quem fez login. Posts públicos são baixados sem problema.",
    errRegion: "O autor restringiu este post por país, então ele não pode ser baixado.",
    errServerBlocked: "A plataforma está limitando nosso servidor temporariamente. Tente de novo mais tarde.",
    errFailed: "O download falhou. Tente de novo ou escolha outra qualidade.",
    errGeneric: "Algo deu errado. Tente de novo daqui a pouco.",
    acctButton: (p) => `🔑 Conectar sua conta do ${p} ao bot`,
    acctWarn: (p) =>
      `O @VideonerBot poderá baixar com sua conta do ${p} o que só quem fez login vê: stories, posts privados. As plataformas não gostam de downloads automáticos e podem restringir a conta — melhor conectar uma secundária. O navegador vai pedir permissão para ler os cookies deste site; só os cookies do ${p} vão para o servidor, criptografados.`,
    acctConfirm: "Conectar",
    acctCancel: "Cancelar",
    acctSending: "Conectando…",
    acctDenied: "Não é possível conectar a conta sem a permissão de acesso aos cookies.",
    acctNoLogin: (p) => `Você não está logado no ${p} neste navegador. Faça login no site e tente de novo.`,
    acctFailed: "Não deu certo. Tente de novo daqui a pouco.",
    acctCodeTitle: (p) => `Código para conectar o ${p}:`,
    acctCodeHelp:
      "Envie-o ao @VideonerBot no chat privado — para seus próprios downloads. Para um grupo, envie /connect CODE no grupo. O código vale por 10 minutos.",
    acctCopy: "Copiar",
    acctCopied: "Copiado",
    acctOpenBot: "Abrir o bot",
    acctNewCode: "Gerar um novo código",
    acctList: "Minhas conexões no bot",
    acctRevoke: "Revogar acesso aos cookies",
    acctRevoked:
      "Acesso aos cookies revogado — a extensão não os lê mais. As contas já conectadas continuam no bot: remova-as em “Minhas conexões no bot”.",
    playlistOffer: "📃 Baixar a playlist inteira",
    playlistTitle: (title, n) => `📃 Playlist${title ? ` “${title}”` : ""}: ${n} vídeos`,
    playlistHint: "Vou baixar um por um. Você pode fechar esta janela.",
    playlist720: "Playlist em 720p",
    playlistBest: "Playlist na melhor qualidade",
    playlistAudio: "Playlist — só áudio (mp3)",
    playlistProgress: (i, n) => `Vídeo ${i} de ${n}`,
    playlistStats: (done, failed) => `Baixados: ${done}${failed ? ` · com falha: ${failed}` : ""}`,
    playlistStop: "⏹ Parar",
    playlistDone: (done, n) => `Playlist baixada: ${done} de ${n}.`,
    playlistStopped: (done, n) => `Parado. Baixados: ${done} de ${n}.`,
    playlistLoading: "Obtendo a lista de vídeos…",
    close: "Fechar",
    updateAvailable: (v) => `A versão ${v} está disponível.`,
    updateHow: "Como atualizar",
    langAuto: "Auto",
    langLabel: "Idioma",
  },
  es: {
    loading: "Obteniendo información del video…",
    notVideoPage:
      "Abre la página de un video en YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest o Threads y vuelve a hacer clic en el ícono. Clase de GetCourse: si la página de la clase estaba abierta antes de instalar la extensión, recárgala.",
    gcLesson: "Clase de GetCourse",
    gcPick: "Esta clase tiene varios videos: elige uno",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Tu navegador descarga y une el video. Puedes cerrar esta ventana, pero no el navegador.",
    gcNoStream: "No se pudo obtener el video del reproductor. Recarga la clase e inténtalo de nuevo.",
    video: "Video",
    photo: "Fotos en tamaño original",
    slideshow: "Presentación (video)",
    gallery: "Fotos + presentación",
    audioOnly: "Solo audio (mp3)",
    subtitles: "Subtítulos (.srt)",
    subtitlesAuto: "automáticos",
    back: "Atrás",
    starting: "Iniciando la descarga…",
    waiting: "Esperando un lugar libre en el servidor…",
    downloading: "Descargando",
    converting: "Procesando",
    left: (eta) => `quedan ${eta}`,
    saving: "Guardando en Descargas…",
    done: "Listo: el archivo está en Descargas.",
    news: "📣 Novedades del proyecto: @videonerdownload",
    again: "Descargar otro",
    directDownload: "Descargar video (mp4)",
    directPhoto: "Descargar foto (jpg)",
    directNote: "Directo desde el navegador, sin cola en el servidor",
    moreOptions: "Otras calidades y audio",
    fallback: "La descarga en el navegador falló: descargando por el servidor.",
    openSite: "Abrir videoner.download",
    retry: "Intentar de nuevo",
    min: "min",
    sec: "s",
    errNetwork: "No se puede conectar con Videoner. Revisa tu conexión e inténtalo de nuevo.",
    errRateLimit: "Demasiadas solicitudes seguidas. Espera un minuto e inténtalo de nuevo.",
    errUnsupported:
      "En esta página no hay ningún video que Videoner pueda descargar. Abre la página de un video o publicación concretos.",
    errYoutubeDaily: "Se agotó el límite diario de YouTube para tu red. Inténtalo de nuevo mañana.",
    errTooLarge: "El archivo es demasiado grande en esta calidad. Elige una menor.",
    errLogin:
      "Esta publicación solo está disponible para usuarios con sesión iniciada. Las publicaciones públicas se descargan sin problema.",
    errRegion: "El autor restringió esta publicación por país, así que no se puede descargar.",
    errServerBlocked: "La plataforma está limitando temporalmente nuestro servidor. Inténtalo de nuevo más tarde.",
    errFailed: "La descarga falló. Inténtalo de nuevo o elige otra calidad.",
    errGeneric: "Algo salió mal. Inténtalo de nuevo en un rato.",
    acctButton: (p) => `🔑 Conecta tu cuenta de ${p} al bot`,
    acctWarn: (p) =>
      `@VideonerBot podrá descargar con tu cuenta de ${p} lo que solo ven los usuarios con sesión iniciada: historias, publicaciones privadas. A las plataformas no les gustan las descargas automáticas y pueden restringir la cuenta: mejor conecta una secundaria. El navegador pedirá permiso para leer las cookies de este sitio; solo las cookies de ${p} van al servidor, cifradas.`,
    acctConfirm: "Conectar",
    acctCancel: "Cancelar",
    acctSending: "Conectando…",
    acctDenied: "No se puede conectar la cuenta sin el permiso de acceso a las cookies.",
    acctNoLogin: (p) => `No has iniciado sesión en ${p} en este navegador. Inicia sesión en el sitio e inténtalo de nuevo.`,
    acctFailed: "No funcionó. Inténtalo de nuevo en un rato.",
    acctCodeTitle: (p) => `Código para conectar ${p}:`,
    acctCodeHelp:
      "Envíalo a @VideonerBot en un chat privado, para tus propias descargas. Para un grupo, envía /connect CODE en el grupo. El código es válido durante 10 minutos.",
    acctCopy: "Copiar",
    acctCopied: "Copiado",
    acctOpenBot: "Abrir el bot",
    acctNewCode: "Obtener un código nuevo",
    acctList: "Mis conexiones en el bot",
    acctRevoke: "Revocar el acceso a las cookies",
    acctRevoked:
      "Acceso a las cookies revocado: la extensión ya no las lee. Las cuentas que ya conectaste siguen en el bot: elimínalas en «Mis conexiones en el bot».",
    playlistOffer: "📃 Descargar toda la lista",
    playlistTitle: (title, n) => `📃 Lista${title ? ` «${title}»` : ""}: ${n} videos`,
    playlistHint: "Los descargaré uno por uno. Puedes cerrar esta ventana.",
    playlist720: "Lista en 720p",
    playlistBest: "Lista en la mejor calidad",
    playlistAudio: "Lista: solo audio (mp3)",
    playlistProgress: (i, n) => `Video ${i} de ${n}`,
    playlistStats: (done, failed) => `Descargados: ${done}${failed ? ` · fallidos: ${failed}` : ""}`,
    playlistStop: "⏹ Detener",
    playlistDone: (done, n) => `Lista descargada: ${done} de ${n}.`,
    playlistStopped: (done, n) => `Detenido. Descargados: ${done} de ${n}.`,
    playlistLoading: "Obteniendo la lista de videos…",
    close: "Cerrar",
    updateAvailable: (v) => `Ya está disponible la versión ${v}.`,
    updateHow: "Cómo actualizar",
    langAuto: "Auto",
    langLabel: "Idioma",
  },
  uz: {
    loading: "Video maʼlumotlari olinmoqda…",
    notVideoPage:
      "YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest yoki Threads saytida video sahifasini oching va belgini yana bosing. GetCourse darsi: agar dars sahifasi kengaytma oʻrnatilishidan oldin ochilgan boʻlsa, uni qayta yuklang.",
    gcLesson: "GetCourse darsi",
    gcPick: "Bu darsda bir nechta video bor — bittasini tanlang",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Brauzeringiz videoni yuklab, birlashtiradi. Bu oynani yopishingiz mumkin, lekin brauzerni emas.",
    gcNoStream: "Videoni pleyerdan olib boʻlmadi. Dars sahifasini qayta yuklang va yana urinib koʻring.",
    video: "Video",
    photo: "Asl oʻlchamdagi rasmlar",
    slideshow: "Slayd-shou (video)",
    gallery: "Rasmlar + slayd-shou",
    audioOnly: "Faqat audio (mp3)",
    subtitles: "Subtitrlar (.srt)",
    subtitlesAuto: "avtomatik",
    back: "Orqaga",
    starting: "Yuklab olish boshlanmoqda…",
    waiting: "Serverda boʻsh joy kutilmoqda…",
    downloading: "Yuklab olinmoqda",
    converting: "Ishlov berilmoqda",
    left: (eta) => `${eta} qoldi`,
    saving: "Yuklanmalarga saqlanmoqda…",
    done: "Tayyor — fayl Yuklanmalar papkasida.",
    news: "📣 Loyiha yangiliklari: @videonerdownload",
    again: "Yana yuklab olish",
    directDownload: "Videoni yuklab olish (mp4)",
    directPhoto: "Rasmni yuklab olish (jpg)",
    directNote: "Toʻgʻridan-toʻgʻri brauzerdan — server navbatisiz",
    moreOptions: "Boshqa sifatlar va audio",
    fallback: "Brauzerda yuklab olib boʻlmadi — server orqali yuklanmoqda.",
    openSite: "videoner.download saytini ochish",
    retry: "Qayta urinish",
    min: "daq",
    sec: "s",
    errNetwork: "Videoner bilan bogʻlanib boʻlmadi. Internetni tekshiring va yana urinib koʻring.",
    errRateLimit: "Ketma-ket juda koʻp soʻrov. Bir daqiqa kuting va yana urinib koʻring.",
    errUnsupported:
      "Bu sahifada Videoner yuklab oladigan video yoʻq. Muayyan video yoki post sahifasini oching.",
    errYoutubeDaily: "Tarmogʻingiz uchun YouTube kunlik limiti tugadi. Ertaga urinib koʻring.",
    errTooLarge: "Bu sifatda fayl juda katta. Pastroq sifatni tanlang.",
    errLogin:
      "Bu post faqat akkauntga kirgan foydalanuvchilarga ochiq. Ommaviy postlar muammosiz yuklab olinadi.",
    errRegion: "Muallif bu postni mamlakat boʻyicha cheklagan, shuning uchun uni yuklab boʻlmaydi.",
    errServerBlocked: "Platforma serverimizni vaqtincha cheklamoqda. Keyinroq urinib koʻring.",
    errFailed: "Yuklab olib boʻlmadi. Yana urinib koʻring yoki boshqa sifatni tanlang.",
    errGeneric: "Nimadir xato ketdi. Birozdan keyin yana urinib koʻring.",
    acctButton: (p) => `🔑 ${p} akkauntingizni botga ulash`,
    acctWarn: (p) =>
      `@VideonerBot akkauntingiz orqali ${p} platformasida faqat akkauntga kirganlar koʻradigan narsalarni yuklab ola oladi: storislar, yopiq postlar. Platformalar avtomatik yuklab olishni yoqtirmaydi va akkauntni cheklashi mumkin — qoʻshimcha akkauntni ulagan maʼqul. Brauzer bu saytning cookie fayllarini oʻqishga ruxsat soʻraydi; serverga faqat ${p} cookie fayllari shifrlangan holda yuboriladi.`,
    acctConfirm: "Ulash",
    acctCancel: "Bekor qilish",
    acctSending: "Ulanmoqda…",
    acctDenied: "Cookie fayllariga ruxsat bermasangiz, akkauntni ulab boʻlmaydi.",
    acctNoLogin: (p) => `Bu brauzerda ${p} akkauntingizga kirmagansiz. Saytda akkauntga kiring va yana urinib koʻring.`,
    acctFailed: "Boʻlmadi. Birozdan keyin yana urinib koʻring.",
    acctCodeTitle: (p) => `${p} akkauntini ulash kodi:`,
    acctCodeHelp:
      "Uni @VideonerBot ga shaxsiy chatda yuboring — oʻzingizning yuklab olishlaringiz uchun. Guruh uchun guruhda /connect CODE yuboring. Kod 10 daqiqa amal qiladi.",
    acctCopy: "Nusxalash",
    acctCopied: "Nusxalandi",
    acctOpenBot: "Botni ochish",
    acctNewCode: "Yangi kod olish",
    acctList: "Botdagi ulanishlarim",
    acctRevoke: "Cookie ruxsatini bekor qilish",
    acctRevoked:
      "Cookie ruxsati bekor qilindi — kengaytma ularni endi oʻqimaydi. Ulangan akkauntlar botda qoladi: ularni «Botdagi ulanishlarim» boʻlimida oʻchiring.",
    playlistOffer: "📃 Butun pleylistni yuklab olish",
    playlistTitle: (title, n) => `📃 Pleylist${title ? ` «${title}»` : ""}: ${n} ta video`,
    playlistHint: "Ularni birma-bir yuklab olaman. Bu oynani yopishingiz mumkin.",
    playlist720: "Pleylist 720p sifatda",
    playlistBest: "Pleylist eng yaxshi sifatda",
    playlistAudio: "Pleylist — faqat audio (mp3)",
    playlistProgress: (i, n) => `${n} tadan ${i}-video`,
    playlistStats: (done, failed) => `Yuklab olindi: ${done}${failed ? ` · xato: ${failed}` : ""}`,
    playlistStop: "⏹ Toʻxtatish",
    playlistDone: (done, n) => `Pleylist yuklab olindi: ${n} tadan ${done} ta.`,
    playlistStopped: (done, n) => `Toʻxtatildi. Yuklab olindi: ${n} tadan ${done} ta.`,
    playlistLoading: "Videolar roʻyxati olinmoqda…",
    close: "Yopish",
    updateAvailable: (v) => `${v} versiyasi chiqdi.`,
    updateHow: "Qanday yangilash mumkin",
    langAuto: "Avto",
    langLabel: "Til",
  },
  tr: {
    loading: "Video bilgileri alınıyor…",
    notVideoPage:
      "YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest veya Threads'te bir video sayfası açın ve simgeye tekrar tıklayın. GetCourse dersi: ders sayfası eklenti yüklenmeden önce açıldıysa sayfayı yenileyin.",
    gcLesson: "GetCourse dersi",
    gcPick: "Bu derste birkaç video var — birini seçin",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Videoyu tarayıcınız indirip birleştirir. Bu pencereyi kapatabilirsiniz, tarayıcıyı değil.",
    gcNoStream: "Video oynatıcıdan alınamadı. Ders sayfasını yenileyin ve tekrar deneyin.",
    video: "Video",
    photo: "Orijinal boyutta fotoğraflar",
    slideshow: "Slayt gösterisi (video)",
    gallery: "Fotoğraflar + slayt gösterisi",
    audioOnly: "Yalnızca ses (mp3)",
    subtitles: "Altyazılar (.srt)",
    subtitlesAuto: "otomatik",
    back: "Geri",
    starting: "İndirme başlatılıyor…",
    waiting: "Sunucuda boş yer bekleniyor…",
    downloading: "İndiriliyor",
    converting: "İşleniyor",
    left: (eta) => `${eta} kaldı`,
    saving: "İndirilenler'e kaydediliyor…",
    done: "Hazır — dosya İndirilenler klasörünüzde.",
    news: "📣 Proje haberleri: @videonerdownload",
    again: "Başka bir video indir",
    directDownload: "Videoyu indir (mp4)",
    directPhoto: "Fotoğrafı indir (jpg)",
    directNote: "Doğrudan tarayıcınızdan — sunucu sırası yok",
    moreOptions: "Diğer kaliteler ve ses",
    fallback: "Tarayıcıda indirilemedi — sunucu üzerinden indiriliyor.",
    openSite: "videoner.download'u aç",
    retry: "Tekrar dene",
    min: "dk",
    sec: "sn",
    errNetwork: "Videoner'a bağlanılamıyor. İnternet bağlantınızı kontrol edip tekrar deneyin.",
    errRateLimit: "Arka arkaya çok fazla istek. Bir dakika bekleyip tekrar deneyin.",
    errUnsupported:
      "Bu sayfada Videoner'ın indirebileceği bir video yok. Belirli bir videonun veya gönderinin sayfasını açın.",
    errYoutubeDaily: "Ağınız için günlük YouTube sınırı doldu. Yarın tekrar deneyin.",
    errTooLarge: "Bu kalitede dosya çok büyük. Daha düşük bir kalite seçin.",
    errLogin:
      "Bu gönderi yalnızca giriş yapmış kullanıcılara açık. Herkese açık gönderiler sorunsuz indirilir.",
    errRegion: "Yazar bu gönderiyi ülkeye göre kısıtlamış, bu yüzden indirilemiyor.",
    errServerBlocked: "Platform sunucumuzu geçici olarak kısıtlıyor. Lütfen daha sonra tekrar deneyin.",
    errFailed: "İndirilemedi. Tekrar deneyin veya başka bir kalite seçin.",
    errGeneric: "Bir şeyler ters gitti. Lütfen biraz sonra tekrar deneyin.",
    acctButton: (p) => `🔑 ${p} hesabınızı bota bağlayın`,
    acctWarn: (p) =>
      `@VideonerBot, hesabınızı kullanarak ${p} platformunda yalnızca giriş yapanların gördüğü içerikleri indirebilecek: hikâyeler, gizli gönderiler. Platformlar otomatik indirmeyi sevmez ve hesabı kısıtlayabilir — ikincil bir hesap bağlamanız daha iyi olur. Tarayıcı bu sitenin çerezlerini okumak için izin isteyecek; sunucuya yalnızca ${p} çerezleri şifrelenmiş olarak gönderilir.`,
    acctConfirm: "Bağla",
    acctCancel: "İptal",
    acctSending: "Bağlanıyor…",
    acctDenied: "Çerez izni olmadan hesap bağlanamaz.",
    acctNoLogin: (p) => `Bu tarayıcıda ${p} hesabınıza giriş yapmamışsınız. Sitede giriş yapıp tekrar deneyin.`,
    acctFailed: "Olmadı. Biraz sonra tekrar deneyin.",
    acctCodeTitle: (p) => `${p} bağlantı kodu:`,
    acctCodeHelp:
      "Kodu @VideonerBot'a özel sohbette gönderin — kendi indirmeleriniz için. Bir grup için grupta /connect CODE gönderin. Kod 10 dakika geçerlidir.",
    acctCopy: "Kopyala",
    acctCopied: "Kopyalandı",
    acctOpenBot: "Botu aç",
    acctNewCode: "Yeni kod al",
    acctList: "Bottaki bağlantılarım",
    acctRevoke: "Çerez erişimini iptal et",
    acctRevoked:
      "Çerez erişimi iptal edildi — eklenti artık onları okumuyor. Bağladığınız hesaplar botta kalır: onları “Bottaki bağlantılarım” bölümünden kaldırın.",
    playlistOffer: "📃 Tüm oynatma listesini indir",
    playlistTitle: (title, n) => `📃 Oynatma listesi${title ? ` "${title}"` : ""}: ${n} video`,
    playlistHint: "Videoları tek tek indireceğim. Bu pencereyi kapatabilirsiniz.",
    playlist720: "Oynatma listesi 720p",
    playlistBest: "Oynatma listesi en iyi kalitede",
    playlistAudio: "Oynatma listesi — yalnızca ses (mp3)",
    playlistProgress: (i, n) => `Video ${i} / ${n}`,
    playlistStats: (done, failed) => `İndirilen: ${done}${failed ? ` · hata: ${failed}` : ""}`,
    playlistStop: "⏹ Durdur",
    playlistDone: (done, n) => `Oynatma listesi indirildi: ${done} / ${n}.`,
    playlistStopped: (done, n) => `Durduruldu. İndirilen: ${done} / ${n}.`,
    playlistLoading: "Video listesi alınıyor…",
    close: "Kapat",
    updateAvailable: (v) => `${v} sürümü çıktı.`,
    updateHow: "Nasıl güncellenir",
    langAuto: "Otomatik",
    langLabel: "Dil",
  },
  // Персидский (фарси), справа налево, как арабский: персидские ی/ک,
  // полупробел (ZWNJ) в «می‌…», «…‌ها»; латиница (@VideonerBot, /connect,
  // .srt) изолирована знаками направления, как в ar.
  fa: {
    loading: "در حال دریافت اطلاعات ویدیو…",
    notVideoPage:
      "یک صفحهٔ ویدیو در YouTube، TikTok، Instagram، Facebook، X، Vimeo، VK، Rutube، OK.ru، Pinterest یا Threads باز کنید و دوباره روی نماد کلیک کنید. درس GetCourse: اگر صفحهٔ درس پیش از نصب افزونه باز بوده، آن را دوباره بارگیری کنید.",
    gcLesson: "درس GetCourse",
    gcPick: "این درس چند ویدیو دارد — یکی را انتخاب کنید",
    gcVideo: (n) => `ویدیو ${n}`,
    gcNote: "مرورگر شما ویدیو را دانلود و یکپارچه می‌کند. می‌توانید این پنجره را ببندید، اما مرورگر را نه.",
    gcNoStream: "دریافت ویدیو از پخش‌کننده ممکن نشد. صفحهٔ درس را دوباره بارگیری کنید و دوباره تلاش کنید.",
    video: "ویدیو",
    photo: "عکس‌ها در اندازهٔ اصلی",
    slideshow: "اسلایدشو (ویدیو)",
    gallery: "عکس‌ها + اسلایدشو",
    audioOnly: "فقط صدا (mp3)",
    subtitles: "زیرنویس (⁦.srt⁩)",
    subtitlesAuto: "خودکار",
    back: "بازگشت",
    starting: "در حال شروع دانلود…",
    waiting: "در انتظار نوبت روی سرور…",
    downloading: "در حال دانلود",
    converting: "در حال پردازش",
    left: (eta) => `${eta} باقی مانده`,
    saving: "در حال ذخیره در «دانلودها»…",
    done: "انجام شد — فایل در «دانلودها» است.",
    news: "📣 اخبار پروژه: ⁦@videonerdownload⁩",
    again: "دانلود ویدیوی دیگر",
    directDownload: "دانلود ویدیو (mp4)",
    directPhoto: "دانلود عکس (jpg)",
    directNote: "مستقیم از مرورگر شما — بدون صف سرور",
    moreOptions: "کیفیت‌های دیگر و صدا",
    fallback: "دانلود در مرورگر ممکن نشد — در حال دانلود از طریق سرور.",
    openSite: "باز کردن videoner.download",
    retry: "دوباره تلاش کنید",
    min: "دقیقه",
    sec: "ثانیه",
    errNetwork: "اتصال به Videoner ممکن نیست. اتصال اینترنت خود را بررسی کنید و دوباره تلاش کنید.",
    errRateLimit: "درخواست‌های پشت‌سرهم زیادی ارسال شده است. یک دقیقه صبر کنید و دوباره تلاش کنید.",
    errUnsupported:
      "در این صفحه ویدیویی نیست که Videoner بتواند دانلود کند. صفحهٔ یک ویدیو یا پست مشخص را باز کنید.",
    errYoutubeDaily: "سهمیهٔ روزانهٔ YouTube برای شبکهٔ شما تمام شده است. فردا دوباره تلاش کنید.",
    errTooLarge: "فایل در این کیفیت بیش از حد بزرگ است. کیفیت پایین‌تری انتخاب کنید.",
    errLogin:
      "این پست فقط برای کاربرانی که وارد حساب خود شده‌اند در دسترس است. پست‌های عمومی بدون مشکل دانلود می‌شوند.",
    errRegion: "نویسنده این پست را بر اساس کشور محدود کرده است، به همین دلیل دانلود آن ممکن نیست.",
    errServerBlocked: "پلتفرم موقتاً دسترسی سرور ما را محدود کرده است. لطفاً بعداً دوباره تلاش کنید.",
    errFailed: "دانلود انجام نشد. دوباره تلاش کنید یا کیفیت دیگری انتخاب کنید.",
    errGeneric: "مشکلی پیش آمد. لطفاً کمی بعد دوباره تلاش کنید.",
    acctButton: (p) => `🔑 اتصال حساب ${p} شما به ربات`,
    acctWarn: (p) =>
      `⁦@VideonerBot⁩ با استفاده از حساب شما می‌تواند محتوایی را که در ${p} فقط کاربران واردشده می‌بینند دانلود کند: استوری‌ها و پست‌های خصوصی. پلتفرم‌ها دانلود خودکار را دوست ندارند و ممکن است حساب را محدود کنند — بهتر است یک حساب فرعی متصل کنید. مرورگر برای خواندن کوکی‌های این سایت اجازه می‌خواهد؛ فقط کوکی‌های ${p} به‌صورت رمزگذاری‌شده به سرور فرستاده می‌شوند.`,
    acctConfirm: "اتصال",
    acctCancel: "لغو",
    acctSending: "در حال اتصال…",
    acctDenied: "بدون اجازهٔ دسترسی به کوکی‌ها نمی‌توان حساب را متصل کرد.",
    acctNoLogin: (p) => `در این مرورگر وارد حساب ${p} خود نشده‌اید. در سایت وارد شوید و دوباره تلاش کنید.`,
    acctFailed: "انجام نشد. کمی بعد دوباره تلاش کنید.",
    acctCodeTitle: (p) => `کد اتصال ${p}:`,
    acctCodeHelp:
      "آن را در گفت‌وگوی خصوصی به ⁦@VideonerBot⁩ بفرستید — برای دانلودهای خودتان. برای یک گروه، در همان گروه ⁦/connect کد⁩ را بفرستید. کد 10 دقیقه اعتبار دارد.",
    acctCopy: "کپی",
    acctCopied: "کپی شد",
    acctOpenBot: "باز کردن ربات",
    acctNewCode: "دریافت کد جدید",
    acctList: "اتصال‌های من در ربات",
    acctRevoke: "لغو دسترسی به کوکی‌ها",
    acctRevoked:
      "دسترسی به کوکی‌ها لغو شد — افزونه دیگر آن‌ها را نمی‌خواند. حساب‌هایی که قبلاً متصل کرده‌اید در ربات می‌مانند: آن‌ها را در «اتصال‌های من در ربات» حذف کنید.",
    playlistOffer: "📃 دانلود کل فهرست پخش",
    playlistTitle: (title, n) => `📃 فهرست پخش${title ? ` «⁨${title}⁩»` : ""}: ${n} ویدیو`,
    playlistHint: "آن‌ها را یکی‌یکی دانلود می‌کنم. می‌توانید این پنجره را ببندید.",
    playlist720: "فهرست پخش با کیفیت 720p",
    playlistBest: "فهرست پخش با بهترین کیفیت",
    playlistAudio: "فهرست پخش — فقط صدا (mp3)",
    playlistProgress: (i, n) => `ویدیو ${i} از ${n}`,
    playlistStats: (done, failed) => `دانلودشده: ${done}${failed ? ` · ناموفق: ${failed}` : ""}`,
    playlistStop: "⏹ توقف",
    playlistDone: (done, n) => `فهرست پخش دانلود شد: ${done} از ${n}.`,
    playlistStopped: (done, n) => `متوقف شد. دانلودشده: ${done} از ${n}.`,
    playlistLoading: "در حال دریافت فهرست ویدیوها…",
    close: "بستن",
    updateAvailable: (v) => `نسخهٔ ${v} منتشر شد.`,
    updateHow: "نحوهٔ به‌روزرسانی",
    langAuto: "خودکار",
    langLabel: "زبان",
  },
  // Вьетнамский, обращение «bạn».
  vi: {
    loading: "Đang lấy thông tin video…",
    notVideoPage:
      "Mở trang video trên YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest hoặc Threads rồi nhấn lại vào biểu tượng. Bài học GetCourse: nếu trang bài học đã mở trước khi cài tiện ích, hãy tải lại trang.",
    gcLesson: "Bài học GetCourse",
    gcPick: "Bài học này có nhiều video — hãy chọn một",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Trình duyệt của bạn sẽ tải và ghép video. Bạn có thể đóng cửa sổ này, nhưng đừng đóng trình duyệt.",
    gcNoStream: "Không lấy được video từ trình phát. Hãy tải lại trang bài học và thử lại.",
    video: "Video",
    photo: "Ảnh kích thước gốc",
    slideshow: "Trình chiếu (video)",
    gallery: "Ảnh + trình chiếu",
    audioOnly: "Chỉ âm thanh (mp3)",
    subtitles: "Phụ đề (.srt)",
    subtitlesAuto: "tự động",
    back: "Quay lại",
    starting: "Đang bắt đầu tải…",
    waiting: "Đang chờ chỗ trống trên máy chủ…",
    downloading: "Đang tải",
    converting: "Đang xử lý",
    left: (eta) => `còn ${eta}`,
    saving: "Đang lưu vào Tệp tải xuống…",
    done: "Xong — tệp đã nằm trong Tệp tải xuống.",
    news: "📣 Tin tức dự án: @videonerdownload",
    again: "Tải video khác",
    directDownload: "Tải video (mp4)",
    directPhoto: "Tải ảnh (jpg)",
    directNote: "Trực tiếp từ trình duyệt — không qua hàng đợi máy chủ",
    moreOptions: "Chất lượng khác và âm thanh",
    fallback: "Không tải được trong trình duyệt — đang tải qua máy chủ.",
    openSite: "Mở videoner.download",
    retry: "Thử lại",
    min: "phút",
    sec: "giây",
    errNetwork: "Không kết nối được với Videoner. Hãy kiểm tra kết nối mạng và thử lại.",
    errRateLimit: "Quá nhiều yêu cầu liên tiếp. Hãy đợi một phút rồi thử lại.",
    errUnsupported:
      "Trang này không có video nào Videoner tải được. Hãy mở trang của một video hoặc bài đăng cụ thể.",
    errYoutubeDaily: "Đã hết giới hạn YouTube trong ngày cho mạng của bạn. Hãy thử lại vào ngày mai.",
    errTooLarge: "Tệp ở chất lượng này quá lớn. Hãy chọn chất lượng thấp hơn.",
    errLogin:
      "Bài đăng này chỉ dành cho người đã đăng nhập. Bài đăng công khai tải bình thường.",
    errRegion: "Tác giả đã giới hạn bài đăng này theo quốc gia nên không thể tải.",
    errServerBlocked: "Nền tảng đang tạm thời hạn chế máy chủ của chúng tôi. Vui lòng thử lại sau.",
    errFailed: "Tải không thành công. Hãy thử lại hoặc chọn chất lượng khác.",
    errGeneric: "Đã xảy ra lỗi. Vui lòng thử lại sau ít phút.",
    acctButton: (p) => `🔑 Kết nối tài khoản ${p} của bạn với bot`,
    acctWarn: (p) =>
      `@VideonerBot sẽ dùng tài khoản của bạn để tải những gì trên ${p} chỉ người đã đăng nhập mới xem được: story, bài đăng riêng tư. Các nền tảng không thích tải tự động và có thể hạn chế tài khoản — tốt hơn hãy kết nối một tài khoản phụ. Trình duyệt sẽ xin quyền đọc cookie của trang này; chỉ cookie của ${p} được gửi lên máy chủ, đã mã hóa.`,
    acctConfirm: "Kết nối",
    acctCancel: "Hủy",
    acctSending: "Đang kết nối…",
    acctDenied: "Không thể kết nối tài khoản khi chưa cấp quyền đọc cookie.",
    acctNoLogin: (p) => `Bạn chưa đăng nhập ${p} trong trình duyệt này. Hãy đăng nhập trên trang web rồi thử lại.`,
    acctFailed: "Không thành công. Hãy thử lại sau ít phút.",
    acctCodeTitle: (p) => `Mã kết nối ${p}:`,
    acctCodeHelp:
      "Gửi mã cho @VideonerBot trong chat riêng — để tải cho chính bạn. Với nhóm, hãy gửi /connect MÃ trong nhóm. Mã có hiệu lực 10 phút.",
    acctCopy: "Sao chép",
    acctCopied: "Đã sao chép",
    acctOpenBot: "Mở bot",
    acctNewCode: "Lấy mã mới",
    acctList: "Kết nối của tôi trong bot",
    acctRevoke: "Thu hồi quyền đọc cookie",
    acctRevoked:
      "Đã thu hồi quyền đọc cookie — tiện ích không còn đọc chúng nữa. Các tài khoản đã kết nối vẫn còn trong bot: hãy xóa chúng trong “Kết nối của tôi trong bot”.",
    playlistOffer: "📃 Tải cả danh sách phát",
    playlistTitle: (title, n) => `📃 Danh sách phát${title ? ` "${title}"` : ""}: ${n} video`,
    playlistHint: "Mình sẽ tải lần lượt từng video. Bạn có thể đóng cửa sổ này.",
    playlist720: "Danh sách phát 720p",
    playlistBest: "Danh sách phát chất lượng cao nhất",
    playlistAudio: "Danh sách phát — chỉ âm thanh (mp3)",
    playlistProgress: (i, n) => `Video ${i} / ${n}`,
    playlistStats: (done, failed) => `Đã tải: ${done}${failed ? ` · lỗi: ${failed}` : ""}`,
    playlistStop: "⏹ Dừng",
    playlistDone: (done, n) => `Đã tải danh sách phát: ${done} / ${n}.`,
    playlistStopped: (done, n) => `Đã dừng. Đã tải: ${done} / ${n}.`,
    playlistLoading: "Đang lấy danh sách video…",
    close: "Đóng",
    updateAvailable: (v) => `Đã có phiên bản ${v}.`,
    updateHow: "Cách cập nhật",
    langAuto: "Tự động",
    langLabel: "Ngôn ngữ",
  },
  bn: {
    loading: "ভিডিওর তথ্য আনা হচ্ছে…",
    notVideoPage:
      "YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest বা Threads-এ একটি ভিডিওর পেজ খুলে আবার আইকনে ক্লিক করুন। GetCourse লেসন: এক্সটেনশন ইনস্টলের আগে লেসনের পেজ খোলা থাকলে পেজটি রিলোড করুন।",
    gcLesson: "GetCourse লেসন",
    gcPick: "এই লেসনে কয়েকটি ভিডিও আছে — একটি বেছে নিন",
    gcVideo: (n) => `ভিডিও ${n}`,
    gcNote: "আপনার ব্রাউজার ভিডিওটি ডাউনলোড করে জোড়া লাগাবে। এই উইন্ডো বন্ধ করতে পারেন, কিন্তু ব্রাউজার নয়।",
    gcNoStream: "প্লেয়ার থেকে ভিডিও পাওয়া যায়নি। লেসনের পেজ রিলোড করে আবার চেষ্টা করুন।",
    video: "ভিডিও",
    photo: "আসল সাইজের ছবি",
    slideshow: "স্লাইডশো (ভিডিও)",
    gallery: "ছবি + স্লাইডশো",
    audioOnly: "শুধু অডিও (mp3)",
    subtitles: "সাবটাইটেল (.srt)",
    subtitlesAuto: "স্বয়ংক্রিয়",
    back: "পিছনে",
    starting: "ডাউনলোড শুরু হচ্ছে…",
    waiting: "সার্ভারে খালি জায়গার অপেক্ষা…",
    downloading: "ডাউনলোড হচ্ছে",
    converting: "প্রসেস হচ্ছে",
    left: (eta) => `বাকি ${eta}`,
    saving: "ডাউনলোডস-এ সেভ হচ্ছে…",
    done: "সম্পন্ন — ফাইলটি আপনার ডাউনলোডস-এ আছে।",
    news: "📣 প্রজেক্টের খবর: @videonerdownload",
    again: "আরেকটি ডাউনলোড করুন",
    directDownload: "ভিডিও ডাউনলোড (mp4)",
    directPhoto: "ছবি ডাউনলোড (jpg)",
    directNote: "সরাসরি ব্রাউজার থেকে — সার্ভারের সারি ছাড়াই",
    moreOptions: "অন্য কোয়ালিটি ও অডিও",
    fallback: "ব্রাউজারে ডাউনলোড হয়নি — সার্ভারের মাধ্যমে ডাউনলোড হচ্ছে।",
    openSite: "videoner.download খুলুন",
    retry: "আবার চেষ্টা করুন",
    min: "মিনিট",
    sec: "সেকেন্ড",
    errNetwork: "Videoner-এর সাথে সংযোগ করা যাচ্ছে না। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।",
    errRateLimit: "পরপর অনেক বেশি অনুরোধ। এক মিনিট অপেক্ষা করে আবার চেষ্টা করুন।",
    errUnsupported:
      "এই পেজে এমন কোনো ভিডিও নেই যা Videoner ডাউনলোড করতে পারে। নির্দিষ্ট কোনো ভিডিও বা পোস্টের পেজ খুলুন।",
    errYoutubeDaily: "আপনার নেটওয়ার্কের দৈনিক YouTube সীমা শেষ। আগামীকাল আবার চেষ্টা করুন।",
    errTooLarge: "এই কোয়ালিটিতে ফাইলটি অনেক বড়। কম কোয়ালিটি বেছে নিন।",
    errLogin:
      "এই পোস্টটি শুধু সাইন ইন করা ব্যবহারকারীরা দেখতে পারেন। পাবলিক পোস্ট কোনো সমস্যা ছাড়াই ডাউনলোড হয়।",
    errRegion: "লেখক এই পোস্টটি দেশ অনুযায়ী সীমিত করেছেন, তাই এটি ডাউনলোড করা যাবে না।",
    errServerBlocked: "প্ল্যাটফর্মটি সাময়িকভাবে আমাদের সার্ভার সীমিত করছে। দয়া করে পরে আবার চেষ্টা করুন।",
    errFailed: "ডাউনলোড ব্যর্থ হয়েছে। আবার চেষ্টা করুন বা অন্য কোয়ালিটি বেছে নিন।",
    errGeneric: "কিছু একটা ভুল হয়েছে। একটু পরে আবার চেষ্টা করুন।",
    acctButton: (p) => `🔑 আপনার ${p} অ্যাকাউন্ট বটের সাথে যুক্ত করুন`,
    acctWarn: (p) =>
      `@VideonerBot আপনার অ্যাকাউন্ট দিয়ে ${p}-এ শুধু সাইন ইন করা ব্যবহারকারীদের দেখা কনটেন্ট ডাউনলোড করতে পারবে: স্টোরি, প্রাইভেট পোস্ট। প্ল্যাটফর্মগুলো স্বয়ংক্রিয় ডাউনলোড পছন্দ করে না এবং অ্যাকাউন্ট সীমিত করতে পারে — তাই একটি দ্বিতীয় অ্যাকাউন্ট যুক্ত করাই ভালো। ব্রাউজার এই সাইটের কুকি পড়ার অনুমতি চাইবে; শুধু ${p}-এর কুকি এনক্রিপ্ট করে সার্ভারে পাঠানো হয়।`,
    acctConfirm: "যুক্ত করুন",
    acctCancel: "বাতিল",
    acctSending: "যুক্ত করা হচ্ছে…",
    acctDenied: "কুকির অনুমতি ছাড়া অ্যাকাউন্ট যুক্ত করা যাবে না।",
    acctNoLogin: (p) => `এই ব্রাউজারে আপনি ${p}-এ সাইন ইন করেননি। সাইটে সাইন ইন করে আবার চেষ্টা করুন।`,
    acctFailed: "হয়নি। একটু পরে আবার চেষ্টা করুন।",
    acctCodeTitle: (p) => `${p} যুক্ত করার কোড:`,
    acctCodeHelp:
      "নিজের ডাউনলোডের জন্য কোডটি প্রাইভেট চ্যাটে @VideonerBot-কে পাঠান। গ্রুপের জন্য গ্রুপে /connect কোড পাঠান। কোডটি 10 মিনিট বৈধ থাকবে।",
    acctCopy: "কপি করুন",
    acctCopied: "কপি হয়েছে",
    acctOpenBot: "বট খুলুন",
    acctNewCode: "নতুন কোড নিন",
    acctList: "বটে আমার সংযোগগুলো",
    acctRevoke: "কুকি অ্যাক্সেস বাতিল করুন",
    acctRevoked:
      "কুকি অ্যাক্সেস বাতিল হয়েছে — এক্সটেনশন আর এগুলো পড়ে না। আগে যুক্ত করা অ্যাকাউন্টগুলো বটে থেকে যাবে: “বটে আমার সংযোগগুলো”-তে গিয়ে সেগুলো সরান।",
    playlistOffer: "📃 পুরো প্লেলিস্ট ডাউনলোড করুন",
    playlistTitle: (title, n) => `📃 প্লেলিস্ট${title ? ` "${title}"` : ""}: ${n}টি ভিডিও`,
    playlistHint: "একটা একটা করে ডাউনলোড করব। এই উইন্ডো বন্ধ করতে পারেন।",
    playlist720: "প্লেলিস্ট 720p-তে",
    playlistBest: "প্লেলিস্ট সেরা কোয়ালিটিতে",
    playlistAudio: "প্লেলিস্ট — শুধু অডিও (mp3)",
    playlistProgress: (i, n) => `ভিডিও ${i} / ${n}`,
    playlistStats: (done, failed) => `ডাউনলোড হয়েছে: ${done}${failed ? ` · ব্যর্থ: ${failed}` : ""}`,
    playlistStop: "⏹ থামান",
    playlistDone: (done, n) => `প্লেলিস্ট ডাউনলোড হয়েছে: ${n}টির মধ্যে ${done}টি।`,
    playlistStopped: (done, n) => `থামানো হয়েছে। ডাউনলোড হয়েছে ${n}টির মধ্যে ${done}টি।`,
    playlistLoading: "ভিডিওর তালিকা আনা হচ্ছে…",
    close: "বন্ধ করুন",
    updateAvailable: (v) => `সংস্করণ ${v} প্রকাশিত হয়েছে।`,
    updateHow: "কীভাবে আপডেট করবেন",
    langAuto: "স্বয়ংক্রিয়",
    langLabel: "ভাষা",
  },
  // Урду, справа налево, как арабский и персидский: буквы урду ی/ک/ہ/ے,
  // обращение «آپ», точка «۔»; латиница (@VideonerBot, /connect, .srt)
  // изолирована знаками направления, как в fa.
  ur: {
    loading: "ویڈیو کی معلومات حاصل کی جا رہی ہیں…",
    notVideoPage:
      "YouTube، TikTok، Instagram، Facebook، X، Vimeo، VK، Rutube، OK.ru، Pinterest یا Threads پر کسی ویڈیو کا صفحہ کھولیں اور دوبارہ آئیکن پر کلک کریں۔ GetCourse سبق: اگر سبق کا صفحہ ایکسٹینشن انسٹال کرنے سے پہلے کھلا تھا تو اسے دوبارہ لوڈ کریں۔",
    gcLesson: "GetCourse سبق",
    gcPick: "اس سبق میں کئی ویڈیوز ہیں — ایک منتخب کریں",
    gcVideo: (n) => `ویڈیو ${n}`,
    gcNote: "آپ کا براؤزر ویڈیو ڈاؤن لوڈ کر کے جوڑ دے گا۔ آپ یہ ونڈو بند کر سکتے ہیں، لیکن براؤزر نہیں۔",
    gcNoStream: "پلیئر سے ویڈیو حاصل نہیں ہو سکی۔ سبق کا صفحہ دوبارہ لوڈ کریں اور پھر کوشش کریں۔",
    video: "ویڈیو",
    photo: "اصل سائز میں تصاویر",
    slideshow: "سلائیڈ شو (ویڈیو)",
    gallery: "تصاویر + سلائیڈ شو",
    audioOnly: "صرف آڈیو (mp3)",
    subtitles: "سب ٹائٹلز (⁦.srt⁩)",
    subtitlesAuto: "خودکار",
    back: "واپس",
    starting: "ڈاؤن لوڈ شروع ہو رہا ہے…",
    waiting: "سرور پر باری کا انتظار ہے…",
    downloading: "ڈاؤن لوڈ ہو رہا ہے",
    converting: "پروسیسنگ ہو رہی ہے",
    left: (eta) => `${eta} باقی`,
    saving: "“ڈاؤن لوڈز” میں محفوظ کیا جا رہا ہے…",
    done: "ہو گیا — فائل “ڈاؤن لوڈز” میں ہے۔",
    news: "📣 پروجیکٹ کی خبریں: ⁦@videonerdownload⁩",
    again: "دوسری ویڈیو ڈاؤن لوڈ کریں",
    directDownload: "ویڈیو ڈاؤن لوڈ کریں (mp4)",
    directPhoto: "تصویر ڈاؤن لوڈ کریں (jpg)",
    directNote: "براہِ راست آپ کے براؤزر سے — سرور کی قطار کے بغیر",
    moreOptions: "دیگر کوالٹیز اور آڈیو",
    fallback: "براؤزر میں ڈاؤن لوڈ نہیں ہو سکا — سرور کے ذریعے ڈاؤن لوڈ ہو رہا ہے۔",
    openSite: "videoner.download کھولیں",
    retry: "دوبارہ کوشش کریں",
    min: "منٹ",
    sec: "سیکنڈ",
    errNetwork: "Videoner سے رابطہ نہیں ہو سکا۔ اپنا انٹرنیٹ کنکشن چیک کریں اور دوبارہ کوشش کریں۔",
    errRateLimit: "ایک ساتھ بہت زیادہ درخواستیں بھیجی گئی ہیں۔ ایک منٹ انتظار کریں اور دوبارہ کوشش کریں۔",
    errUnsupported:
      "اس صفحے پر کوئی ایسی ویڈیو نہیں جسے Videoner ڈاؤن لوڈ کر سکے۔ کسی مخصوص ویڈیو یا پوسٹ کا صفحہ کھولیں۔",
    errYoutubeDaily: "آپ کے نیٹ ورک کے لیے YouTube کی روزانہ حد ختم ہو گئی ہے۔ کل دوبارہ کوشش کریں۔",
    errTooLarge: "اس کوالٹی میں فائل بہت بڑی ہے۔ کم کوالٹی منتخب کریں۔",
    errLogin:
      "یہ پوسٹ صرف لاگ اِن صارفین کے لیے دستیاب ہے۔ عوامی پوسٹس بغیر کسی مسئلے کے ڈاؤن لوڈ ہوتی ہیں۔",
    errRegion: "مصنف نے اس پوسٹ کو ملک کے لحاظ سے محدود کر دیا ہے، اس لیے اسے ڈاؤن لوڈ نہیں کیا جا سکتا۔",
    errServerBlocked: "پلیٹ فارم نے عارضی طور پر ہمارے سرور کو محدود کر دیا ہے۔ براہِ کرم بعد میں دوبارہ کوشش کریں۔",
    errFailed: "ڈاؤن لوڈ نہیں ہو سکا۔ دوبارہ کوشش کریں یا کوئی اور کوالٹی منتخب کریں۔",
    errGeneric: "کچھ غلط ہو گیا۔ براہِ کرم تھوڑی دیر بعد دوبارہ کوشش کریں۔",
    acctButton: (p) => `🔑 اپنا ${p} اکاؤنٹ بوٹ سے جوڑیں`,
    acctWarn: (p) =>
      `⁦@VideonerBot⁩ آپ کے اکاؤنٹ کے ذریعے وہ مواد ڈاؤن لوڈ کر سکے گا جو ${p} پر صرف لاگ اِن صارفین دیکھ سکتے ہیں: اسٹوریز اور نجی پوسٹس۔ پلیٹ فارمز خودکار ڈاؤن لوڈ پسند نہیں کرتے اور اکاؤنٹ کو محدود کر سکتے ہیں — بہتر ہے کہ کوئی ثانوی اکاؤنٹ جوڑیں۔ براؤزر اس سائٹ کی کوکیز پڑھنے کی اجازت مانگے گا؛ صرف ${p} کی کوکیز خفیہ شکل میں سرور کو بھیجی جاتی ہیں۔`,
    acctConfirm: "جوڑیں",
    acctCancel: "منسوخ کریں",
    acctSending: "جوڑا جا رہا ہے…",
    acctDenied: "کوکیز تک رسائی کی اجازت کے بغیر اکاؤنٹ نہیں جوڑا جا سکتا۔",
    acctNoLogin: (p) => `آپ اس براؤزر میں ${p} میں لاگ اِن نہیں ہیں۔ سائٹ پر لاگ اِن کریں اور دوبارہ کوشش کریں۔`,
    acctFailed: "نہیں ہو سکا۔ تھوڑی دیر بعد دوبارہ کوشش کریں۔",
    acctCodeTitle: (p) => `${p} جوڑنے کا کوڈ:`,
    acctCodeHelp:
      "اسے نجی چیٹ میں ⁦@VideonerBot⁩ کو بھیجیں — اپنے ڈاؤن لوڈز کے لیے۔ گروپ کے لیے، اسی گروپ میں ⁦/connect کوڈ⁩ بھیجیں۔ کوڈ 10 منٹ تک کارآمد ہے۔",
    acctCopy: "کاپی کریں",
    acctCopied: "کاپی ہو گیا",
    acctOpenBot: "بوٹ کھولیں",
    acctNewCode: "نیا کوڈ حاصل کریں",
    acctList: "بوٹ میں میرے کنکشنز",
    acctRevoke: "کوکیز تک رسائی واپس لیں",
    acctRevoked:
      "کوکیز تک رسائی واپس لے لی گئی — ایکسٹینشن اب انہیں نہیں پڑھے گی۔ جو اکاؤنٹس آپ پہلے جوڑ چکے ہیں وہ بوٹ میں رہیں گے: انہیں “بوٹ میں میرے کنکشنز” میں ہٹائیں۔",
    playlistOffer: "📃 پوری پلے لسٹ ڈاؤن لوڈ کریں",
    playlistTitle: (title, n) => `📃 پلے لسٹ${title ? ` “⁨${title}⁩”` : ""}: ${n} ویڈیوز`,
    playlistHint: "میں انہیں ایک ایک کر کے ڈاؤن لوڈ کروں گا۔ آپ یہ ونڈو بند کر سکتے ہیں۔",
    playlist720: "پلے لسٹ 720p میں",
    playlistBest: "پلے لسٹ بہترین کوالٹی میں",
    playlistAudio: "پلے لسٹ — صرف آڈیو (mp3)",
    playlistProgress: (i, n) => `${n} میں سے ویڈیو ${i}`,
    playlistStats: (done, failed) => `ڈاؤن لوڈ شدہ: ${done}${failed ? ` · ناکام: ${failed}` : ""}`,
    playlistStop: "⏹ روکیں",
    playlistDone: (done, n) => `پلے لسٹ ڈاؤن لوڈ ہو گئی: ${n} میں سے ${done}۔`,
    playlistStopped: (done, n) => `روک دیا گیا۔ ڈاؤن لوڈ شدہ: ${n} میں سے ${done}۔`,
    playlistLoading: "ویڈیوز کی فہرست حاصل کی جا رہی ہے…",
    close: "بند کریں",
    updateAvailable: (v) => `ورژن ${v} جاری ہو گیا ہے۔`,
    updateHow: "اپ ڈیٹ کیسے کریں",
    langAuto: "خودکار",
    langLabel: "زبان",
  },
  pl: {
    loading: "Pobieram informacje o filmie…",
    notVideoPage:
      "Otwórz stronę z filmem na YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest lub Threads i kliknij ikonę jeszcze raz. Lekcja GetCourse: jeśli strona lekcji była otwarta przed instalacją rozszerzenia, odśwież ją.",
    gcLesson: "Lekcja GetCourse",
    gcPick: "W tej lekcji jest kilka filmów — wybierz jeden",
    gcVideo: (n) => `Film ${n}`,
    gcNote: "Pobiera i łączy go twoja przeglądarka. Możesz zamknąć to okienko, ale nie przeglądarkę.",
    gcNoStream: "Nie udało się pobrać filmu z odtwarzacza. Odśwież stronę lekcji i spróbuj ponownie.",
    video: "Wideo",
    photo: "Zdjęcia w oryginalnym rozmiarze",
    slideshow: "Pokaz slajdów (wideo)",
    gallery: "Zdjęcia + pokaz slajdów",
    audioOnly: "Tylko dźwięk (mp3)",
    subtitles: "Napisy (.srt)",
    subtitlesAuto: "automatyczne",
    back: "Wstecz",
    starting: "Uruchamiam pobieranie…",
    waiting: "Czekam na swoją kolej na serwerze…",
    downloading: "Pobieram",
    converting: "Przetwarzam",
    left: (eta) => `zostało ${eta}`,
    saving: "Zapisuję w „Pobranych”…",
    done: "Gotowe — plik jest w „Pobranych”.",
    news: "📣 Nowości projektu: @videonerdownload",
    again: "Pobierz kolejny",
    directDownload: "Pobierz wideo (mp4)",
    directPhoto: "Pobierz zdjęcie (jpg)",
    directNote: "Prosto z przeglądarki — bez kolejki na serwerze",
    moreOptions: "Inne jakości i dźwięk",
    fallback: "Z przeglądarki się nie udało — pobieram przez serwer.",
    openSite: "Otwórz videoner.download",
    retry: "Spróbuj ponownie",
    min: "min",
    sec: "s",
    errNetwork: "Brak połączenia z Videoner. Sprawdź internet i spróbuj ponownie.",
    errRateLimit: "Za dużo zapytań naraz. Odczekaj minutę i spróbuj ponownie.",
    errUnsupported:
      "Na tej stronie nie ma filmu, który Videoner potrafi pobrać. Otwórz stronę konkretnego filmu lub posta.",
    errYoutubeDaily: "Dzienny limit YouTube dla twojej sieci się wyczerpał. Spróbuj jutro.",
    errTooLarge: "Plik w tej jakości jest za duży. Wybierz niższą jakość.",
    errLogin:
      "Ten post jest dostępny tylko dla zalogowanych. Publiczne posty pobierają się bez problemu.",
    errRegion: "Autor ograniczył ten post do wybranych krajów, więc nie da się go pobrać.",
    errServerBlocked: "Platforma tymczasowo ogranicza dostęp naszemu serwerowi. Spróbuj później.",
    errFailed: "Nie udało się pobrać. Spróbuj ponownie lub wybierz inną jakość.",
    errGeneric: "Coś poszło nie tak. Spróbuj ponownie za chwilę.",
    acctButton: (p) => `🔑 Połącz swoje konto ${p} z botem`,
    acctWarn: (p) =>
      `@VideonerBot będzie mógł pobierać z twojego konta ${p} to, co widzą tylko zalogowani: relacje, prywatne posty. Platformy nie lubią automatycznego pobierania i mogą ograniczyć konto — lepiej połącz zapasowe. Przeglądarka poprosi o dostęp do ciasteczek tej strony; na serwer trafią tylko ciasteczka ${p}, zaszyfrowane.`,
    acctConfirm: "Połącz",
    acctCancel: "Anuluj",
    acctSending: "Łączę…",
    acctDenied: "Bez dostępu do ciasteczek nie da się połączyć konta.",
    acctNoLogin: (p) => `Nie jesteś zalogowany w ${p} w tej przeglądarce. Zaloguj się na stronie i spróbuj ponownie.`,
    acctFailed: "Nie udało się. Spróbuj ponownie za chwilę.",
    acctCodeTitle: (p) => `Kod do połączenia ${p}:`,
    acctCodeHelp:
      "Wyślij go do @VideonerBot na prywatnym czacie — do własnych pobrań. Dla grupy wyślij w grupie /connect KOD. Kod jest ważny 10 minut.",
    acctCopy: "Kopiuj",
    acctCopied: "Skopiowano",
    acctOpenBot: "Otwórz bota",
    acctNewCode: "Pobierz nowy kod",
    acctList: "Moje połączenia w bocie",
    acctRevoke: "Cofnij dostęp do ciasteczek",
    acctRevoked:
      "Dostęp do ciasteczek cofnięty — rozszerzenie już ich nie czyta. Połączone wcześniej konta zostają w bocie: odłączysz je w „Moje połączenia w bocie”.",
    playlistOffer: "📃 Pobierz całą playlistę",
    playlistTitle: (title, n) => `📃 Playlista${title ? ` „${title}”` : ""} · filmów: ${n}`,
    playlistHint: "Pobiorę je po kolei, jeden po drugim. Możesz zamknąć to okienko.",
    playlist720: "Playlista w 720p",
    playlistBest: "Playlista w najlepszej jakości",
    playlistAudio: "Playlista — tylko dźwięk (mp3)",
    playlistProgress: (i, n) => `Film ${i} z ${n}`,
    playlistStats: (done, failed) => `Pobrano: ${done}${failed ? ` · nieudane: ${failed}` : ""}`,
    playlistStop: "⏹ Zatrzymaj",
    playlistDone: (done, n) => `Playlista pobrana: ${done} z ${n}.`,
    playlistStopped: (done, n) => `Zatrzymano. Pobrano ${done} z ${n}.`,
    playlistLoading: "Pobieram listę filmów…",
    close: "Zamknij",
    updateAvailable: (v) => `Wyszła nowa wersja ${v}.`,
    updateHow: "Jak zaktualizować",
    langAuto: "Auto",
    langLabel: "Język",
  },
  // Японский, вежливый стиль (です/ます), японская пунктуация (、。「」).
  // Латиница (названия площадок, @VideonerBot, /connect), цифры и GB/MB —
  // как в английском.
  ja: {
    loading: "動画情報を取得しています…",
    notVideoPage:
      "YouTube、TikTok、Instagram、Facebook、X、Vimeo、VK、Rutube、OK.ru、Pinterest、Threads の動画ページを開いて、もう一度アイコンをクリックしてください。GetCourse のレッスン：拡張機能をインストールする前からレッスンページを開いていた場合は、ページを再読み込みしてください。",
    gcLesson: "GetCourse のレッスン",
    gcPick: "このレッスンには動画が複数あります。1 つ選んでください",
    gcVideo: (n) => `動画 ${n}`,
    gcNote: "ブラウザがダウンロードして結合します。このウィンドウは閉じても構いませんが、ブラウザは閉じないでください。",
    gcNoStream: "プレーヤーから動画を取得できませんでした。レッスンページを再読み込みして、もう一度お試しください。",
    video: "動画",
    photo: "元のサイズの写真",
    slideshow: "スライドショー（動画）",
    gallery: "写真 + スライドショー",
    audioOnly: "音声のみ（mp3）",
    subtitles: "字幕（.srt）",
    subtitlesAuto: "自動生成",
    back: "戻る",
    starting: "ダウンロードを開始しています…",
    waiting: "サーバーの空きを待っています…",
    downloading: "ダウンロード中",
    converting: "処理中",
    left: (eta) => `残り ${eta}`,
    saving: "「ダウンロード」に保存しています…",
    done: "完了しました。ファイルは「ダウンロード」にあります。",
    news: "📣 プロジェクトのお知らせ：@videonerdownload",
    again: "別の動画をダウンロード",
    directDownload: "動画をダウンロード（mp4）",
    directPhoto: "写真をダウンロード（jpg）",
    directNote: "ブラウザから直接ダウンロード、サーバーの順番待ちなし",
    moreOptions: "その他の画質と音声",
    fallback: "ブラウザでのダウンロードに失敗したため、サーバー経由でダウンロードします。",
    openSite: "videoner.download を開く",
    retry: "もう一度試す",
    min: "分",
    sec: "秒",
    errNetwork: "Videoner に接続できません。インターネット接続を確認して、もう一度お試しください。",
    errRateLimit: "連続したリクエストが多すぎます。1 分ほど待ってから、もう一度お試しください。",
    errUnsupported:
      "このページには Videoner でダウンロードできる動画がありません。個別の動画や投稿のページを開いてください。",
    errYoutubeDaily: "お使いのネットワークの YouTube の 1 日の上限に達しました。明日もう一度お試しください。",
    errTooLarge: "この画質ではファイルが大きすぎます。より低い画質を選んでください。",
    errLogin:
      "この投稿はログインしたユーザーしか見られません。公開されている投稿は問題なくダウンロードできます。",
    errRegion: "投稿者がこの投稿の閲覧を国・地域で制限しているため、ダウンロードできません。",
    errServerBlocked: "プラットフォームが一時的にサーバーへのアクセスを制限しています。しばらくしてから、もう一度お試しください。",
    errFailed: "ダウンロードに失敗しました。もう一度試すか、別の画質を選んでください。",
    errGeneric: "問題が発生しました。少し時間をおいて、もう一度お試しください。",
    acctButton: (p) => `🔑 ${p} アカウントをボットに接続`,
    acctWarn: (p) =>
      `@VideonerBot があなたのアカウントを使って、${p} でログインしたユーザーにしか見えないもの（ストーリーズ、非公開の投稿）をダウンロードできるようになります。プラットフォームは自動ダウンロードを好まず、アカウントを制限することがあるため、サブアカウントの接続をおすすめします。ブラウザがこのサイトの Cookie を読み取る許可を求めます。サーバーに送られるのは ${p} の Cookie だけで、暗号化されます。`,
    acctConfirm: "接続する",
    acctCancel: "キャンセル",
    acctSending: "接続しています…",
    acctDenied: "Cookie の許可がないと、アカウントを接続できません。",
    acctNoLogin: (p) => `このブラウザで ${p} にログインしていません。サイトでログインしてから、もう一度お試しください。`,
    acctFailed: "うまくいきませんでした。少し時間をおいて、もう一度お試しください。",
    acctCodeTitle: (p) => `${p} の接続コード：`,
    acctCodeHelp:
      "ご自身のダウンロード用には、@VideonerBot との個人チャットに送信してください。グループ用には、グループで /connect コード を送信してください。コードの有効期限は 10 分です。",
    acctCopy: "コピー",
    acctCopied: "コピーしました",
    acctOpenBot: "ボットを開く",
    acctNewCode: "新しいコードを取得",
    acctList: "ボットでの接続一覧",
    acctRevoke: "Cookie へのアクセスを取り消す",
    acctRevoked:
      "Cookie へのアクセスを取り消しました。拡張機能が Cookie を読み取ることはもうありません。接続済みのアカウントはボットに残ります。「ボットでの接続一覧」から削除してください。",
    playlistOffer: "📃 再生リストをすべてダウンロード",
    playlistTitle: (title, n) => `📃 再生リスト${title ? `「${title}」` : ""}：動画 ${n} 本`,
    playlistHint: "1 本ずつ順番にダウンロードします。このウィンドウは閉じても構いません。",
    playlist720: "再生リスト（720p）",
    playlistBest: "再生リスト（最高画質）",
    playlistAudio: "再生リスト — 音声のみ（mp3）",
    playlistProgress: (i, n) => `動画 ${i} / ${n}`,
    playlistStats: (done, failed) => `ダウンロード済み：${done}${failed ? ` · 失敗：${failed}` : ""}`,
    playlistStop: "⏹ 停止",
    playlistDone: (done, n) => `再生リストのダウンロードが完了しました：${done} / ${n}。`,
    playlistStopped: (done, n) => `停止しました。${done} / ${n} 本をダウンロードしました。`,
    playlistLoading: "動画の一覧を取得しています…",
    close: "閉じる",
    updateAvailable: (v) => `バージョン ${v} が公開されました。`,
    updateHow: "更新方法",
    langAuto: "自動",
    langLabel: "言語",
  },
  // Корейский, вежливый стиль 해요체. Латиница (названия площадок,
  // @VideonerBot, /connect), цифры и GB/MB — как в английском.
  ko: {
    loading: "동영상 정보를 가져오는 중…",
    notVideoPage:
      "YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest 또는 Threads의 동영상 페이지를 열고 아이콘을 다시 클릭하세요. GetCourse 강의: 확장 프로그램을 설치하기 전에 강의 페이지를 열어 두었다면 페이지를 새로고침하세요.",
    gcLesson: "GetCourse 강의",
    gcPick: "이 강의에는 동영상이 여러 개 있어요. 하나를 선택하세요",
    gcVideo: (n) => `동영상 ${n}`,
    gcNote: "브라우저가 다운로드하고 합쳐요. 이 창은 닫아도 되지만 브라우저는 닫지 마세요.",
    gcNoStream: "플레이어에서 동영상을 가져오지 못했어요. 강의 페이지를 새로고침하고 다시 시도하세요.",
    video: "동영상",
    photo: "원본 크기 사진",
    slideshow: "슬라이드쇼(동영상)",
    gallery: "사진 + 슬라이드쇼",
    audioOnly: "오디오만(mp3)",
    subtitles: "자막(.srt)",
    subtitlesAuto: "자동 생성",
    back: "뒤로",
    starting: "다운로드를 시작하는 중…",
    waiting: "서버 대기열을 기다리는 중…",
    downloading: "다운로드 중",
    converting: "처리 중",
    left: (eta) => `${eta} 남음`,
    saving: "'다운로드' 폴더에 저장하는 중…",
    done: "완료됐어요. 파일은 '다운로드' 폴더에 있어요.",
    news: "📣 프로젝트 소식: @videonerdownload",
    again: "다른 동영상 다운로드",
    directDownload: "동영상 다운로드(mp4)",
    directPhoto: "사진 다운로드(jpg)",
    directNote: "브라우저에서 바로 다운로드, 서버 대기 없음",
    moreOptions: "다른 화질과 오디오",
    fallback: "브라우저 다운로드에 실패해서 서버를 통해 다운로드해요.",
    openSite: "videoner.download 열기",
    retry: "다시 시도",
    min: "분",
    sec: "초",
    errNetwork: "Videoner에 연결할 수 없어요. 인터넷 연결을 확인하고 다시 시도하세요.",
    errRateLimit: "요청이 너무 많아요. 1분 정도 기다린 후 다시 시도하세요.",
    errUnsupported:
      "이 페이지에는 Videoner로 다운로드할 수 있는 동영상이 없어요. 개별 동영상이나 게시물 페이지를 여세요.",
    errYoutubeDaily: "사용 중인 네트워크의 YouTube 일일 한도를 모두 썼어요. 내일 다시 시도하세요.",
    errTooLarge: "이 화질에서는 파일이 너무 커요. 더 낮은 화질을 선택하세요.",
    errLogin:
      "이 게시물은 로그인한 사용자만 볼 수 있어요. 공개 게시물은 문제없이 다운로드돼요.",
    errRegion: "작성자가 이 게시물을 국가별로 제한해서 다운로드할 수 없어요.",
    errServerBlocked: "플랫폼이 일시적으로 서버 접근을 제한하고 있어요. 잠시 후 다시 시도하세요.",
    errFailed: "다운로드에 실패했어요. 다시 시도하거나 다른 화질을 선택하세요.",
    errGeneric: "문제가 발생했어요. 잠시 후 다시 시도하세요.",
    acctButton: (p) => `🔑 내 ${p} 계정을 봇에 연결`,
    acctWarn: (p) =>
      `@VideonerBot이 회원님의 계정으로 ${p}에서 로그인한 사용자만 볼 수 있는 콘텐츠(스토리, 비공개 게시물)를 다운로드할 수 있게 돼요. 플랫폼은 자동 다운로드를 좋아하지 않아 계정을 제한할 수 있으니 보조 계정을 연결하는 것이 좋아요. 브라우저가 이 사이트의 쿠키를 읽을 권한을 요청해요. 서버에는 ${p} 쿠키만 암호화되어 전송돼요.`,
    acctConfirm: "연결",
    acctCancel: "취소",
    acctSending: "연결하는 중…",
    acctDenied: "쿠키 권한이 없으면 계정을 연결할 수 없어요.",
    acctNoLogin: (p) => `이 브라우저에서 ${p}에 로그인되어 있지 않아요. 사이트에서 로그인한 후 다시 시도하세요.`,
    acctFailed: "잘 되지 않았어요. 잠시 후 다시 시도하세요.",
    acctCodeTitle: (p) => `${p} 연결 코드:`,
    acctCodeHelp:
      "본인 다운로드용이라면 @VideonerBot과의 개인 채팅으로 보내세요. 그룹용이라면 그룹에서 /connect 코드 를 보내세요. 코드는 10분 동안 유효해요.",
    acctCopy: "복사",
    acctCopied: "복사됨",
    acctOpenBot: "봇 열기",
    acctNewCode: "새 코드 받기",
    acctList: "봇에 연결된 내 계정",
    acctRevoke: "쿠키 접근 권한 취소",
    acctRevoked:
      "쿠키 접근 권한을 취소했어요. 이제 확장 프로그램이 쿠키를 읽지 않아요. 이미 연결한 계정은 봇에 남아 있으니 '봇에 연결된 내 계정'에서 삭제하세요.",
    playlistOffer: "📃 재생목록 전체 다운로드",
    playlistTitle: (title, n) => `📃 재생목록${title ? ` '${title}'` : ""}: 동영상 ${n}개`,
    playlistHint: "하나씩 차례로 다운로드할게요. 이 창은 닫아도 돼요.",
    playlist720: "재생목록(720p)",
    playlistBest: "재생목록(최고 화질)",
    playlistAudio: "재생목록 — 오디오만(mp3)",
    playlistProgress: (i, n) => `동영상 ${i}/${n}`,
    playlistStats: (done, failed) => `다운로드 완료: ${done}${failed ? ` · 실패: ${failed}` : ""}`,
    playlistStop: "⏹ 중지",
    playlistDone: (done, n) => `재생목록 다운로드 완료: ${done}/${n}.`,
    playlistStopped: (done, n) => `중지했어요. ${n}개 중 ${done}개를 다운로드했어요.`,
    playlistLoading: "동영상 목록을 가져오는 중…",
    close: "닫기",
    updateAvailable: (v) => `새 버전 ${v}이(가) 나왔어요.`,
    updateHow: "업데이트 방법",
    langAuto: "자동",
    langLabel: "언어",
  },
  // Тайский, вежливый дружелюбный тон (без ครับ/ค่ะ). Латиница (названия
  // площадок, @VideonerBot, /connect), цифры (th-TH-u-nu-latn) и GB/MB — как в английском.
  th: {
    loading: "กำลังดึงข้อมูลวิดีโอ…",
    notVideoPage:
      "เปิดหน้าวิดีโอบน YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest หรือ Threads แล้วคลิกไอคอนอีกครั้ง บทเรียน GetCourse: หากเปิดหน้าบทเรียนไว้ก่อนติดตั้งส่วนขยาย ให้โหลดหน้านั้นใหม่",
    gcLesson: "บทเรียน GetCourse",
    gcPick: "บทเรียนนี้มีวิดีโอหลายรายการ เลือกหนึ่งรายการ",
    gcVideo: (n) => `วิดีโอ ${n}`,
    gcNote: "เบราว์เซอร์ของคุณจะดาวน์โหลดและรวมไฟล์ให้ ปิดหน้าต่างนี้ได้ แต่อย่าปิดเบราว์เซอร์",
    gcNoStream: "ดึงวิดีโอจากเพลเยอร์ไม่ได้ โหลดหน้าบทเรียนใหม่แล้วลองอีกครั้ง",
    video: "วิดีโอ",
    photo: "รูปภาพขนาดต้นฉบับ",
    slideshow: "สไลด์โชว์ (วิดีโอ)",
    gallery: "รูปภาพ + สไลด์โชว์",
    audioOnly: "เฉพาะเสียง (mp3)",
    subtitles: "ซับไตเติล (.srt)",
    subtitlesAuto: "สร้างอัตโนมัติ",
    back: "ย้อนกลับ",
    starting: "กำลังเริ่มดาวน์โหลด…",
    waiting: "กำลังรอคิวบนเซิร์ฟเวอร์…",
    downloading: "กำลังดาวน์โหลด",
    converting: "กำลังประมวลผล",
    left: (eta) => `เหลืออีก ${eta}`,
    saving: "กำลังบันทึกลงในโฟลเดอร์ดาวน์โหลด…",
    done: "เสร็จแล้ว ไฟล์อยู่ในโฟลเดอร์ดาวน์โหลดของคุณ",
    news: "📣 ข่าวสารโปรเจกต์: @videonerdownload",
    again: "ดาวน์โหลดวิดีโออื่น",
    directDownload: "ดาวน์โหลดวิดีโอ (mp4)",
    directPhoto: "ดาวน์โหลดรูปภาพ (jpg)",
    directNote: "ดาวน์โหลดจากเบราว์เซอร์โดยตรง ไม่ต้องรอคิวเซิร์ฟเวอร์",
    moreOptions: "คุณภาพอื่นและเสียง",
    fallback: "ดาวน์โหลดผ่านเบราว์เซอร์ไม่สำเร็จ กำลังดาวน์โหลดผ่านเซิร์ฟเวอร์แทน",
    openSite: "เปิด videoner.download",
    retry: "ลองอีกครั้ง",
    min: "นาที",
    sec: "วินาที",
    errNetwork: "เชื่อมต่อ Videoner ไม่ได้ ตรวจสอบการเชื่อมต่ออินเทอร์เน็ตแล้วลองอีกครั้ง",
    errRateLimit: "ส่งคำขอติดต่อกันมากเกินไป รอสักครู่แล้วลองอีกครั้ง",
    errUnsupported:
      "หน้านี้ไม่มีวิดีโอที่ Videoner ดาวน์โหลดได้ เปิดหน้าของวิดีโอหรือโพสต์ที่ต้องการ",
    errYoutubeDaily: "โควตา YouTube รายวันสำหรับเครือข่ายของคุณหมดแล้ว ลองใหม่พรุ่งนี้",
    errTooLarge: "ไฟล์ในคุณภาพนี้ใหญ่เกินไป เลือกคุณภาพที่ต่ำกว่า",
    errLogin:
      "โพสต์นี้ดูได้เฉพาะผู้ที่เข้าสู่ระบบแล้ว โพสต์สาธารณะดาวน์โหลดได้ตามปกติ",
    errRegion: "ผู้โพสต์จำกัดการเข้าถึงโพสต์นี้ตามประเทศ จึงดาวน์โหลดไม่ได้",
    errServerBlocked: "แพลตฟอร์มกำลังจำกัดการเข้าถึงของเซิร์ฟเวอร์เราชั่วคราว ลองใหม่ภายหลัง",
    errFailed: "ดาวน์โหลดไม่สำเร็จ ลองอีกครั้งหรือเลือกคุณภาพอื่น",
    errGeneric: "เกิดข้อผิดพลาด ลองใหม่อีกครั้งในภายหลัง",
    acctButton: (p) => `🔑 เชื่อมต่อบัญชี ${p} ของคุณกับบอท`,
    acctWarn: (p) =>
      `@VideonerBot จะดาวน์โหลดเนื้อหาบน ${p} ที่ดูได้เฉพาะผู้ที่เข้าสู่ระบบผ่านบัญชีของคุณได้ เช่น สตอรี่ โพสต์ส่วนตัว แพลตฟอร์มไม่ชอบการดาวน์โหลดอัตโนมัติและอาจจำกัดบัญชี จึงควรเชื่อมต่อบัญชีสำรอง เบราว์เซอร์จะขอสิทธิ์อ่านคุกกี้ของเว็บไซต์นี้ และจะส่งเฉพาะคุกกี้ของ ${p} ไปยังเซิร์ฟเวอร์แบบเข้ารหัส`,
    acctConfirm: "เชื่อมต่อ",
    acctCancel: "ยกเลิก",
    acctSending: "กำลังเชื่อมต่อ…",
    acctDenied: "เชื่อมต่อบัญชีไม่ได้หากไม่อนุญาตให้เข้าถึงคุกกี้",
    acctNoLogin: (p) => `คุณยังไม่ได้เข้าสู่ระบบ ${p} ในเบราว์เซอร์นี้ เข้าสู่ระบบบนเว็บไซต์แล้วลองอีกครั้ง`,
    acctFailed: "ไม่สำเร็จ ลองใหม่อีกครั้งในภายหลัง",
    acctCodeTitle: (p) => `รหัสสำหรับเชื่อมต่อ ${p}:`,
    acctCodeHelp:
      "ส่งรหัสนี้ให้ @VideonerBot ในแชตส่วนตัวสำหรับการดาวน์โหลดของคุณเอง สำหรับกลุ่ม ให้ส่ง /connect รหัส ในกลุ่มนั้น รหัสใช้ได้ 10 นาที",
    acctCopy: "คัดลอก",
    acctCopied: "คัดลอกแล้ว",
    acctOpenBot: "เปิดบอท",
    acctNewCode: "รับรหัสใหม่",
    acctList: "การเชื่อมต่อของฉันในบอท",
    acctRevoke: "เพิกถอนสิทธิ์เข้าถึงคุกกี้",
    acctRevoked:
      "เพิกถอนสิทธิ์เข้าถึงคุกกี้แล้ว ส่วนขยายจะไม่อ่านคุกกี้อีก บัญชีที่เชื่อมต่อไว้แล้วยังอยู่ในบอท ลบได้ที่ “การเชื่อมต่อของฉันในบอท”",
    playlistOffer: "📃 ดาวน์โหลดทั้งเพลย์ลิสต์",
    playlistTitle: (title, n) => `📃 เพลย์ลิสต์${title ? ` “${title}”` : ""}: ${n} วิดีโอ`,
    playlistHint: "จะดาวน์โหลดทีละรายการตามลำดับ ปิดหน้าต่างนี้ได้",
    playlist720: "เพลย์ลิสต์ 720p",
    playlistBest: "เพลย์ลิสต์คุณภาพสูงสุด",
    playlistAudio: "เพลย์ลิสต์ — เฉพาะเสียง (mp3)",
    playlistProgress: (i, n) => `วิดีโอ ${i}/${n}`,
    playlistStats: (done, failed) => `ดาวน์โหลดแล้ว: ${done}${failed ? ` · ไม่สำเร็จ: ${failed}` : ""}`,
    playlistStop: "⏹ หยุด",
    playlistDone: (done, n) => `ดาวน์โหลดเพลย์ลิสต์แล้ว: ${done}/${n}`,
    playlistStopped: (done, n) => `หยุดแล้ว ดาวน์โหลดไป ${done} จาก ${n}`,
    playlistLoading: "กำลังดึงรายการวิดีโอ…",
    close: "ปิด",
    updateAvailable: (v) => `เวอร์ชัน ${v} ออกแล้ว`,
    updateHow: "วิธีอัปเดต",
    langAuto: "อัตโนมัติ",
    langLabel: "ภาษา",
  },
  tl: {
    loading: "Kinukuha ang info ng video…",
    notVideoPage:
      "Magbukas ng video page sa YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest o Threads at i-click ulit ang icon. GetCourse lesson: kung bukas na ang lesson page bago na-install ang extension, i-reload ito.",
    gcLesson: "GetCourse lesson",
    gcPick: "May ilang video sa lesson na ito — pumili ng isa",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Ang browser mo ang magda-download at magdudugtong nito. Puwede mong isara ang window na ito, pero hindi ang browser.",
    gcNoStream: "Hindi makuha ang video mula sa player. I-reload ang lesson page at subukan ulit.",
    video: "Video",
    photo: "Mga larawan sa orihinal na laki",
    slideshow: "Slideshow (video)",
    gallery: "Mga larawan + slideshow",
    audioOnly: "Audio lang (mp3)",
    subtitles: "Subtitles (.srt)",
    subtitlesAuto: "auto-generated",
    back: "Bumalik",
    starting: "Sinisimulan ang download…",
    waiting: "Naghihintay ng bakanteng slot sa server…",
    downloading: "Nagda-download",
    converting: "Pinoproseso",
    left: (eta) => `${eta} na lang`,
    saving: "Sine-save sa Downloads…",
    done: "Tapos na — nasa Downloads mo na ang file.",
    news: "📣 Balita ng proyekto: @videonerdownload",
    again: "Mag-download ng iba",
    directDownload: "I-download ang video (mp4)",
    directPhoto: "I-download ang larawan (jpg)",
    directNote: "Diretso mula sa browser mo — walang pila sa server",
    moreOptions: "Ibang quality at audio",
    fallback: "Pumalya ang download sa browser — sa server na lang magda-download.",
    openSite: "Buksan ang videoner.download",
    retry: "Subukan ulit",
    min: "min",
    sec: "s",
    errNetwork: "Hindi maabot ang Videoner. I-check ang koneksyon mo at subukan ulit.",
    errRateLimit: "Sobrang daming sunud-sunod na request. Maghintay ng isang minuto at subukan ulit.",
    errUnsupported:
      "Walang video sa page na ito na kayang i-download ng Videoner. Buksan ang page ng mismong video o post.",
    errYoutubeDaily: "Ubos na ang daily YouTube limit ng network mo. Subukan ulit bukas.",
    errTooLarge: "Masyadong malaki ang file sa quality na ito. Pumili ng mas mababa.",
    errLogin:
      "Para lang sa mga naka-sign in ang post na ito. Walang problema sa pag-download ng mga public post.",
    errRegion: "Nilimitahan ng author ang post na ito ayon sa bansa, kaya hindi ito ma-download.",
    errServerBlocked: "Pansamantalang nililimitahan ng platform ang server namin. Subukan ulit mamaya.",
    errFailed: "Pumalya ang download. Subukan ulit o pumili ng ibang quality.",
    errGeneric: "May nangyaring mali. Subukan ulit mamaya.",
    acctButton: (p) => `🔑 I-connect ang iyong ${p} account sa bot`,
    acctWarn: (p) =>
      `Gamit ang account mo, makakapag-download ang @VideonerBot ng mga nakikita lang ng mga naka-sign in sa ${p}: stories, private posts. Ayaw ng mga platform sa automated downloads at puwede nilang limitahan ang account — mas mabuting mag-connect ng secondary account. Hihingi ang browser ng pahintulot na basahin ang cookies ng site na ito; ang cookies lang ng ${p} ang ipapadala sa server, naka-encrypt.`,
    acctConfirm: "I-connect",
    acctCancel: "Kanselahin",
    acctSending: "Kumokonekta…",
    acctDenied: "Hindi ma-connect ang account kung walang pahintulot sa cookies.",
    acctNoLogin: (p) => `Hindi ka naka-sign in sa ${p} sa browser na ito. Mag-sign in sa site at subukan ulit.`,
    acctFailed: "Hindi ito gumana. Subukan ulit mamaya.",
    acctCodeTitle: (p) => `Code para i-connect ang ${p}:`,
    acctCodeHelp:
      "Ipadala ito sa @VideonerBot sa private chat — para sa sarili mong downloads. Para sa group, ipadala ang /connect CODE sa group. Valid ang code nang 10 minuto.",
    acctCopy: "Kopyahin",
    acctCopied: "Nakopya na",
    acctOpenBot: "Buksan ang bot",
    acctNewCode: "Kumuha ng bagong code",
    acctList: "Mga koneksyon ko sa bot",
    acctRevoke: "Bawiin ang access sa cookies",
    acctRevoked:
      "Binawi na ang access sa cookies — hindi na ito binabasa ng extension. Nananatili sa bot ang mga account na na-connect mo na: alisin ang mga ito sa “Mga koneksyon ko sa bot”.",
    playlistOffer: "📃 I-download ang buong playlist",
    playlistTitle: (title, n) => `📃 Playlist${title ? ` "${title}"` : ""}: ${n} video`,
    playlistHint: "Isa-isa ko silang ida-download. Puwede mong isara ang window na ito.",
    playlist720: "Playlist sa 720p",
    playlistBest: "Playlist sa pinakamataas na quality",
    playlistAudio: "Playlist — audio lang (mp3)",
    playlistProgress: (i, n) => `Video ${i} sa ${n}`,
    playlistStats: (done, failed) => `Na-download: ${done}${failed ? ` · pumalya: ${failed}` : ""}`,
    playlistStop: "⏹ Ihinto",
    playlistDone: (done, n) => `Na-download ang playlist: ${done} sa ${n}.`,
    playlistStopped: (done, n) => `Inihinto. Na-download ang ${done} sa ${n}.`,
    playlistLoading: "Kinukuha ang listahan ng mga video…",
    close: "Isara",
    updateAvailable: (v) => `Labas na ang version ${v}.`,
    updateHow: "Paano mag-update",
    langAuto: "Auto",
    langLabel: "Wika",
  },
  en: {
    loading: "Fetching video info…",
    notVideoPage:
      "Open a video page on YouTube, TikTok, Instagram, Facebook, X, Vimeo, VK, Rutube, OK.ru, Pinterest or Threads and click the icon again. GetCourse lesson: if the lesson page was open before the extension was installed, reload it.",
    gcLesson: "GetCourse lesson",
    gcPick: "This lesson has several videos — pick one",
    gcVideo: (n) => `Video ${n}`,
    gcNote: "Your browser downloads and joins it. You can close this window, but not the browser.",
    gcNoStream: "Couldn't get the video from the player. Reload the lesson page and try again.",
    video: "Video",
    photo: "Photos in original size",
    slideshow: "Slideshow (video)",
    gallery: "Photos + slideshow",
    audioOnly: "Audio only (mp3)",
    subtitles: "Subtitles (.srt)",
    subtitlesAuto: "auto-generated",
    back: "Back",
    starting: "Starting the download…",
    waiting: "Waiting for a free slot on the server…",
    downloading: "Downloading",
    converting: "Processing",
    left: (eta) => `${eta} left`,
    saving: "Saving to Downloads…",
    done: "Done — the file is in your Downloads.",
    news: "📣 Project news: @videonerdownload",
    again: "Download another",
    directDownload: "Download video (mp4)",
    directPhoto: "Download photo (jpg)",
    directNote: "Straight from your browser — no server queue",
    moreOptions: "Other qualities and audio",
    fallback: "The browser download failed — downloading via the server.",
    openSite: "Open videoner.download",
    retry: "Try again",
    min: "min",
    sec: "s",
    errNetwork: "Can't reach Videoner. Check your connection and try again.",
    errRateLimit: "Too many requests in a row. Wait a minute and try again.",
    errUnsupported:
      "There is no video on this page that Videoner can download. Open the page of a specific video or post.",
    errYoutubeDaily: "The daily YouTube limit for your network is used up. Try again tomorrow.",
    errTooLarge: "The file is too large in this quality. Pick a lower one.",
    errLogin:
      "This post is only available to signed-in users. Public posts download without any trouble.",
    errRegion: "The author restricted this post by country, so it can't be downloaded.",
    errServerBlocked: "The platform is temporarily limiting our server. Please try again later.",
    errFailed: "The download failed. Try again or pick another quality.",
    errGeneric: "Something went wrong. Please try again a bit later.",
    acctButton: (p) => `🔑 Connect your ${p} account to the bot`,
    acctWarn: (p) =>
      `@VideonerBot will be able to download what only signed-in people see on ${p} using your account: stories, private posts. Platforms dislike automated downloads and may restrict the account — better connect a secondary one. The browser will ask for permission to read this site's cookies; only ${p} cookies go to the server, encrypted.`,
    acctConfirm: "Connect",
    acctCancel: "Cancel",
    acctSending: "Connecting…",
    acctDenied: "The account can't be connected without the cookies permission.",
    acctNoLogin: (p) => `You're not signed in to ${p} in this browser. Sign in on the site and try again.`,
    acctFailed: "That didn't work. Try again a bit later.",
    acctCodeTitle: (p) => `Code to connect ${p}:`,
    acctCodeHelp:
      "Send it to @VideonerBot in a private chat — for your own downloads. For a group, send /connect CODE in the group. The code is valid for 10 minutes.",
    acctCopy: "Copy",
    acctCopied: "Copied",
    acctOpenBot: "Open the bot",
    acctNewCode: "Get a new code",
    acctList: "My connections in the bot",
    acctRevoke: "Revoke cookie access",
    acctRevoked:
      "Cookie access is revoked — the extension no longer reads them. Accounts you already connected stay in the bot: remove them in “My connections in the bot”.",
    playlistOffer: "📃 Download the whole playlist",
    playlistTitle: (title, n) => `📃 Playlist${title ? ` "${title}"` : ""}: ${n} videos`,
    playlistHint: "I'll download them one by one. You can close this window.",
    playlist720: "Playlist in 720p",
    playlistBest: "Playlist in best quality",
    playlistAudio: "Playlist — audio only (mp3)",
    playlistProgress: (i, n) => `Video ${i} of ${n}`,
    playlistStats: (done, failed) => `Downloaded: ${done}${failed ? ` · failed: ${failed}` : ""}`,
    playlistStop: "⏹ Stop",
    playlistDone: (done, n) => `Playlist downloaded: ${done} of ${n}.`,
    playlistStopped: (done, n) => `Stopped. Downloaded ${done} of ${n}.`,
    playlistLoading: "Getting the list of videos…",
    close: "Close",
    updateAvailable: (v) => `Version ${v} is out.`,
    updateHow: "How to update",
    langAuto: "Auto",
    langLabel: "Language",
  },
};

// Язык окошка: выбранный вручную (список вверху окошка, хранится в
// storage.local под LANG_KEY) или язык браузера — русский, украинский,
// казахский, арабский, китайский (zh-CN, zh-TW, zh-HK → zh, по базовому
// коду), хинди (hi, hi-IN → hi), индонезийский (id, id-ID и старый код in → id), суахили (sw, sw-KE, sw-TZ → sw), немецкий (de, de-DE, de-AT, de-CH → de), французский (fr, fr-FR, fr-CA, fr-BE, fr-CH → fr), итальянский (it, it-IT, it-CH → it), португальский (pt, pt-BR, pt-PT → pt, бразильский вариант), испанский (es, es-ES, es-419, es-MX, es-AR → es), узбекский (uz, uz-UZ, uz-Latn → uz), турецкий (tr, tr-TR → tr), персидский (fa, fa-IR → fa), вьетнамский (vi, vi-VN → vi), бенгальский (bn, bn-BD, bn-IN → bn), урду (ur, ur-PK, ur-IN → ur), польский (pl, pl-PL → pl), японский (ja, ja-JP → ja), корейский (ko, ko-KR → ko), тайский (th, th-TH → th), тагальский/филиппинский (tl, tl-PH, fil, fil-PH → tl), остальным английский. Тот же выбор делают content.js и getcourse.js
// (им модули недоступны). lang и t — живые привязки:
// loadLang() меняет их до первой отрисовки окошка. Арабский, персидский и урду пишутся справа
// налево — окошко ставит dir="rtl" (popup.js, isRtl).
export const LANG_KEY = "uiLang";
export const LANG_NAMES = { id: "Bahasa Indonesia", de: "Deutsch", en: "English", es: "Español", fr: "Français", it: "Italiano", sw: "Kiswahili", uz: "Oʻzbekcha", pl: "Polski", pt: "Português", tl: "Tagalog", vi: "Tiếng Việt", tr: "Türkçe", kk: "Қазақша", ru: "Русский", uk: "Українська", ar: "العربية", ur: "اردو", fa: "فارسی", hi: "हिन्दी", bn: "বাংলা", th: "ไทย", zh: "中文", ja: "日本語", ko: "한국어" };
export const browserLang = pickLang(chrome.i18n.getUILanguage());
export let lang = browserLang;
export let t = TEXTS[lang];

export const isRtl = () => lang === "ar" || lang === "fa" || lang === "ur";

// Страница сайта на текущем языке: английский — без префикса.
export const sitePath = (path) => (lang === "en" ? path : `/${lang}${path}`);

function pickLang(uiLanguage) {
  let base = uiLanguage.toLowerCase().split("-")[0];
  if (base === "in") base = "id"; // старый код индонезийского
  if (base === "fil") base = "tl"; // Chrome называет филиппинский «fil»
  return base in TEXTS ? base : "en";
}

export async function loadLang() {
  const chosen = await chosenLang();
  lang = chosen ?? browserLang;
  t = TEXTS[lang];
}

// null — по языку браузера.
export async function chosenLang() {
  try {
    const value = (await chrome.storage.local.get(LANG_KEY))[LANG_KEY];
    return value in TEXTS ? value : null;
  } catch {
    return null;
  }
}

export async function saveLang(value) {
  if (value) await chrome.storage.local.set({ [LANG_KEY]: value });
  else await chrome.storage.local.remove(LANG_KEY);
}

// Ошибки сервера приходят по-английски и техническим языком (часто это
// текст yt-dlp). Порядок проверок повторяет friendlyError бота
// (bot/src/helpers.ts): региональный запрет и ограничения нашего сервера
// проверяются раньше «нужен вход», потому что в их текстах тоже бывает
// «sign in».
export function friendlyError(error) {
  const status = error?.status;
  const msg = String(error?.message ?? "").toLowerCase();

  if (status === 0 || msg === "network") return t.errNetwork;
  if (status === 429 || msg.includes("rate limit exceeded") || msg.includes("too many requests")) {
    return t.errRateLimit;
  }
  if (msg.includes("daily youtube limit")) return t.errYoutubeDaily;
  if (msg.includes("file too large") || msg.includes("request entity too large")) return t.errTooLarge;
  if (
    msg.includes("url not supported") ||
    msg.includes("invalid url") ||
    msg.includes("url is required") ||
    msg.includes("unsupported url") ||
    msg.includes("unsupported platform")
  ) {
    return t.errUnsupported;
  }
  if (
    msg.includes("not available in your country") ||
    msg.includes("not available in your region") ||
    msg.includes("not available from your location") ||
    msg.includes("blocked outside the author's country")
  ) {
    return t.errRegion;
  }
  if (
    msg.includes("empty media response") ||
    msg.includes("without being logged-in") ||
    msg.includes("rate-limit reached") ||
    msg.includes("confirm you're not a bot") ||
    msg.includes("confirm you’re not a bot")
  ) {
    return t.errServerBlocked;
  }
  if (
    msg.includes("certain audiences") ||
    msg.includes("age-restricted") ||
    msg.includes("age restricted") ||
    msg.includes("login required") ||
    msg.includes("requires authentication") ||
    msg.includes("sign in") ||
    msg.includes("log in") ||
    msg.includes("private") ||
    // У Meta закрытая запись выглядит как ошибка разбора страницы (см.
    // server/src/lib/error-category.ts).
    msg.includes("cannot parse data")
  ) {
    return t.errLogin;
  }
  if (msg === "failed") return t.errFailed;
  return t.errGeneric;
}

// «~3 мин», «40 с» — для строки прогресса.
export function formatEta(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0) return "";
  if (seconds < 60) return `${Math.round(seconds)} ${t.sec}`;
  return `~${Math.round(seconds / 60)} ${t.min}`;
}

export function formatSize(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "";
  const gb = bytes / 1024 ** 3;
  // Арабскому, китайскому, хинди, индонезийскому, суахили, немецкому, итальянскому, португальскому, испанскому, узбекскому, турецкому, персидскому, вьетнамскому, бенгальскому, урду, польскому, японскому, корейскому, тайскому и тагальскому — латинские GB/MB, как и цифры (ar-u-nu-latn, th-TH-u-nu-latn, fa-IR-u-nu-latn, bn-BD-u-nu-latn, ur-PK-u-nu-latn);
  // французскому — свои Go/Mo.
  const latin = lang === "en" || lang === "ar" || lang === "zh" || lang === "hi" || lang === "id" || lang === "sw" || lang === "de" || lang === "it" || lang === "pt" || lang === "es" || lang === "uz" || lang === "tr" || lang === "fa" || lang === "vi" || lang === "bn" || lang === "ur" || lang === "pl" || lang === "ja" || lang === "ko" || lang === "th" || lang === "tl";
  const [gbUnit, mbUnit] = lang === "fr" ? ["Go", "Mo"] : latin ? ["GB", "MB"] : ["ГБ", "МБ"];
  const locale = { ru: "ru-RU", uk: "uk-UA", kk: "kk-KZ", ar: "ar-u-nu-latn", zh: "zh-CN", hi: "hi-IN-u-nu-latn", id: "id-ID", sw: "sw-KE", de: "de-DE", fr: "fr-FR", it: "it-IT", pt: "pt-BR", es: "es-ES", uz: "uz-Latn-UZ", tr: "tr-TR", fa: "fa-IR-u-nu-latn", vi: "vi-VN", bn: "bn-BD-u-nu-latn", ur: "ur-PK-u-nu-latn", pl: "pl-PL", ja: "ja-JP", ko: "ko-KR", th: "th-TH-u-nu-latn", tl: "fil-PH", en: "en-US" }[lang];
  if (gb >= 1) return `~${gb.toLocaleString(locale, { maximumFractionDigits: 1 })} ${gbUnit}`;
  return `~${Math.max(1, Math.round(bytes / 1024 ** 2))} ${mbUnit}`;
}

export function formatDuration(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0) return "";
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const pad = (n) => String(n).padStart(2, "0");
  return h ? `${h}:${pad(m)}:${pad(s % 60)}` : `${m}:${pad(s % 60)}`;
}

// chrome.storage.session. Окошку в рамке на чужой странице Firefox его не даёт
// (как и tabs, см. popup.js; проверено 29.10.2026) — тогда то же самое через
// фоновую часть: чтение и запись — сообщениями «embed-storage», изменения
// присылает соединение «embed-storage» (background.js).
const SESSION = chrome.storage.session;
const viaBackground = (op, extra) => chrome.runtime.sendMessage({ type: "embed-storage", op, ...extra });

export const session = {
  get: (keys = null) => (SESSION ? SESSION.get(keys) : viaBackground("get", { keys }).then((items) => items ?? {})),
  set: (items) => (SESSION ? SESSION.set(items) : viaBackground("set", { items })),
  remove: (keys) => (SESSION ? SESSION.remove(keys) : viaBackground("remove", { keys })),
  // listener(changes) — как у storage.onChanged, только для этой области.
  // Общее storage.onChanged, а не storage.session.onChanged: второго нет в
  // Firefox.
  onChanged(listener) {
    if (SESSION) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "session") listener(changes);
      });
      return;
    }
    // Фоновую часть Firefox может остановить и запустить заново — соединение
    // тогда рвётся. Подключаемся снова и отдаём слушателю пустые изменения:
    // пусть перечитает состояние, пропущенное за время разрыва.
    const connect = () => {
      const port = chrome.runtime.connect({ name: "embed-storage" });
      port.onMessage.addListener(listener);
      port.onDisconnect.addListener(() => setTimeout(() => {
        connect();
        listener(null);
      }, 1_000));
    };
    connect();
  },
};

// Состояние скачиваний живёт в storage.session: окошко закрывается при
// любом клике мимо, а скачивание должно идти дальше и сохраниться в
// «Загрузки» без него. Одна задача на ссылку, у каждой свой ключ: общий
// объект на все задачи терял бы обновления, когда две идут параллельно.
const JOB_PREFIX = "job:";

export const jobKey = (url) => `${JOB_PREFIX}${url}`;

export async function getJob(url) {
  return (await session.get(jobKey(url)))[jobKey(url)] ?? null;
}

export async function getAllJobs() {
  const all = await session.get();
  return Object.entries(all)
    .filter(([key]) => key.startsWith(JOB_PREFIX))
    .map(([, job]) => job);
}

export async function setJob(url, job) {
  if (job) await session.set({ [jobKey(url)]: job });
  else await session.remove(jobKey(url));
}

// Плееры GetCourse во вкладке (getcourse.js): ключ на каждую рамку с плеером,
// значение — хеш видео. Пишет фоновая часть, читает окошко.
export const gcPlayerPrefix = (tabId) => `gc-player:${tabId}:`;
export const gcPlayerKey = (tabId, frameId) => `${gcPlayerPrefix(tabId)}${frameId}`;
