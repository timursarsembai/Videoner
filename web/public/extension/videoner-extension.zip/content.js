/* global videonerIsVideoPage, videonerFindPageMedia, videonerMergeFmp4 */
// Кнопка «Скачать» на странице видео. Плавающая, в углу экрана, а не вставка
// рядом с плеером: у одиннадцати площадок своя вёрстка, и вставки ломались бы
// при каждом их редизайне. По клику над кнопкой открывается то же окошко,
// что по значку расширения (popup.html?embed=1), — в рамке, со ссылкой на
// текущее видео.
//
// Всё живёт в закрытом Shadow DOM: стили площадки не достают до кнопки, а
// скрипты площадки — до её содержимого.

(() => {
  if (window.top !== window || window.__videonerButton) return;
  window.__videonerButton = true;

  // Язык — как в окошке (shared.js): выбранный вручную (storage.local,
  // uiLang) или язык браузера. Выбор читается асинхронно, поэтому сначала
  // подпись по браузеру, потом — по выбору.
  const ui = chrome.i18n.getUILanguage().toLowerCase();
  // Языки с письмом справа налево — как RTL_LANGS в shared.js.
  const RTL = ["ar", "fa", "ur", "ps", "ckb", "ug"];
  const LABELS = { ru: "Скачать", uk: "Завантажити", kk: "Жүктеп алу", ky: "Жүктөп алуу", ce: "Чуяккха", inh: "Чуяккха", av: "Босизе", tt: "Йөкләү", tg: "Боргирӣ", ar: "تحميل", zh: "下载", hi: "डाउनलोड", id: "Unduh", sw: "Pakua", de: "Herunterladen", fr: "Télécharger", it: "Scarica", pt: "Baixar", es: "Descargar", uz: "Yuklab olish", tr: "İndir", fa: "دانلود", vi: "Tải xuống", bn: "ডাউনলোড", ur: "ڈاؤن لوڈ", ps: "ښکته کول", ckb: "داگرتن", ug: "چۈشۈرۈش", pl: "Pobierz", ja: "ダウンロード", ko: "다운로드", th: "ดาวน์โหลด", tl: "I-download", am: "አውርድ", om: "Buusi", ha: "Sauke", so: "Soo deji", ku: "Daxîne", az: "Yüklə", tk: "Ýükle", ms: "Muat turun", nl: "Downloaden", ro: "Descarcă", sq: "Shkarko", bs: "Preuzmi", en: "Download" };
  const HIDES = {
    ru: "Скрыть кнопку для этого видео",
    uk: "Сховати кнопку для цього відео",
    kk: "Осы видео үшін батырманы жасыру",
    ky: "Бул видеодо баскычты жашыруу",
    ce: "ХӀокху видеохь кнопка къайлаяккха",
    inh: "ХӀа видео тӀа кнопка лачкъаде",
    av: "Гьаб видеоялда кнопка бахчизабизе",
    tt: "Бу видеода төймәне яшерү",
    tg: "Пинҳон кардани тугма дар ин видео",
    ar: "إخفاء الزر لهذا الفيديو",
    zh: "隐藏此视频的按钮",
    hi: "इस वीडियो के लिए बटन छिपाएँ",
    id: "Sembunyikan tombol untuk video ini",
    sw: "Ficha kitufe kwa video hii",
    de: "Button für dieses Video ausblenden",
    fr: "Masquer le bouton pour cette vidéo",
    it: "Nascondi il pulsante per questo video",
    pt: "Ocultar o botão neste vídeo",
    es: "Ocultar el botón en este video",
    uz: "Bu video uchun tugmani yashirish",
    tr: "Bu videoda düğmeyi gizle",
    fa: "پنهان کردن دکمه برای این ویدیو",
    vi: "Ẩn nút trên video này",
    bn: "এই ভিডিওতে বোতাম লুকান",
    ur: "اس ویڈیو پر بٹن چھپائیں",
    ps: "په دې ویډیو کې تڼۍ پټه کړئ",
    ckb: "شاردنەوەی دوگمە لەم ڤیدیۆیەدا",
    ug: "بۇ ۋىدىيودىكى كۇنۇپكىنى يوشۇرۇش",
    pl: "Ukryj przycisk dla tego filmu",
    ja: "この動画のボタンを非表示",
    ko: "이 동영상에서 버튼 숨기기",
    th: "ซ่อนปุ่มในวิดีโอนี้",
    tl: "Itago ang button sa video na ito",
    am: "በዚህ ቪዲዮ ላይ ያለውን አዝራር ደብቅ",
    om: "Qabduu viidiyoo kana irratti dhoksi",
    ha: "Ɓoye maɓalli a wannan bidiyo",
    so: "Qari badhanka muuqaalkan",
    ku: "Bişkokê li ser vê vîdyoyê veşêre",
    az: "Bu videoda düyməni gizlət",
    tk: "Bu wideodaky düwmäni gizle",
    ms: "Sembunyikan butang pada video ini",
    nl: "Knop op deze video verbergen",
    ro: "Ascunde butonul pe acest videoclip",
    sq: "Fshihe butonin në këtë video",
    bs: "Sakrij dugme na ovom videu",
    en: "Hide the button for this video",
  };
  const base = { in: "id", fil: "tl", mo: "ro", kmr: "ku" }[ui.split("-")[0]] ?? ui.split("-")[0];
  const l = base in LABELS ? base : "en";
  const PANEL_WIDTH = 360;

  const host = document.createElement("div");
  host.style.cssText = "all: initial; position: fixed; z-index: 2147483647; right: 20px; bottom: 96px;";
  const root = host.attachShadow({ mode: "closed" });
  // Разметка собирается через createElement, а не innerHTML: YouTube включает
  // Trusted Types, и присваивание HTML-строки там может быть запрещено.
  const style = document.createElement("style");
  style.textContent = `
      :host { all: initial; }
      .wrap { position: relative; font: 14px/1.2 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
      .btn {
        display: flex; align-items: center; gap: 8px;
        padding: 8px 14px 8px 8px; border: none; border-radius: 999px;
        background: #6a65d4; color: #fff; cursor: pointer;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.25); font: inherit; font-weight: 600;
      }
      .btn:hover { background: #5a55c4; }
      .btn img { width: 22px; height: 22px; border-radius: 6px; }
      .hide {
        position: absolute; top: -6px; right: -6px; width: 18px; height: 18px;
        border: none; border-radius: 50%; background: #3a3950; color: #fff;
        font: 12px/18px system-ui, sans-serif; text-align: center; cursor: pointer;
        padding: 0; opacity: 0; transition: opacity 0.15s;
      }
      .wrap:hover .hide, .hide:focus-visible { opacity: 1; }
      .panel {
        position: absolute; right: 0; bottom: 52px; width: ${PANEL_WIDTH}px; height: 200px;
        max-height: calc(100vh - 170px); border: none; border-radius: 12px;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.35); display: none;
      }
      .panel.open { display: block; }
  `;
  const wrap = document.createElement("div");
  wrap.className = "wrap";
  // Рамка окошка создаётся только на время, пока окошко открыто (openPanel).
  // Вставленная заранее рамка заставляла Chrome проверять политику
  // безопасности страницы при каждом появлении кнопки, и на сайтах с
  // report-only CSP (Threads) в «Ошибки» расширения сыпалось
  // «upgrade-insecure-requests is ignored…» — не наша ошибка, но шум.
  let panel = null;
  const button = document.createElement("button");
  button.className = "btn";
  button.type = "button";
  button.append(document.createElement("img"), document.createElement("span"));
  const hideButton = document.createElement("button");
  hideButton.className = "hide";
  hideButton.type = "button";
  hideButton.textContent = "×";
  wrap.append(button, hideButton);
  root.append(style, wrap);

  button.querySelector("img").alt = "";
  button.querySelector("img").src = chrome.runtime.getURL("icons/icon-48.png");
  function applyLang(code) {
    const label = button.querySelector("span");
    label.textContent = LABELS[code];
    // Направление — только у подписи кнопки (арабский, персидский и урду справа налево).
    label.dir = RTL.includes(code) ? "rtl" : "";
    hideButton.title = HIDES[code];
    hideButton.setAttribute("aria-label", HIDES[code]);
  }
  applyLang(l);
  chrome.storage.local
    .get("uiLang")
    .then(({ uiLang }) => uiLang in LABELS && applyLang(uiLang))
    .catch(() => {});

  let currentHref = null;
  // Видео, для которого человек скрыл кнопку крестиком: до перехода к другому.
  let hiddenFor = null;

  // Удаляем рамку целиком, а не прячем: закрытое окошко не должно оставаться
  // загруженным и присылать сообщения.
  function closePanel() {
    panel?.remove();
    panel = null;
  }

  function openPanel() {
    panel = document.createElement("iframe");
    panel.className = "panel open";
    panel.title = "Videoner";
    panel.src = chrome.runtime.getURL(`popup.html?embed=1&url=${encodeURIComponent(location.href)}`);
    wrap.prepend(panel);
  }

  button.addEventListener("click", () => {
    if (panel) closePanel();
    else openPanel();
  });

  hideButton.addEventListener("click", () => {
    hiddenFor = location.href;
    closePanel();
    update();
  });

  // Окошко в рамке сообщает свою высоту и просьбу закрыться (см. popup.js).
  // Принимаем только от своей рамки: остальные сообщения страницы не наши.
  window.addEventListener("message", (event) => {
    if (!panel || event.source !== panel.contentWindow || !event.data || event.data.videoner === undefined) return;
    if (event.data.videoner === "height" && Number.isFinite(event.data.height)) {
      panel.style.height = `${Math.ceil(event.data.height)}px`;
    } else if (event.data.videoner === "close") {
      closePanel();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && panel) closePanel();
  });

  function update() {
    const href = location.href;
    if (href !== currentHref) {
      // Перешли к другому видео (на YouTube, TikTok и др. страница при этом
      // не перезагружается) — окошко про прошлое видео больше не к месту.
      currentHref = href;
      closePanel();
      if (hiddenFor && hiddenFor !== href) hiddenFor = null;
    }
    const show = videonerIsVideoPage(href) && hiddenFor !== href && !document.fullscreenElement;
    if (show && !host.isConnected) document.documentElement.append(host);
    if (!show && host.isConnected) host.remove();
  }

  // Скачивание силами браузера (см. page-media.js, background.js). Окошко
  // спрашивает, есть ли на странице готовый mp4; фоновая часть просит скачать
  // его отсюда — запрос со страницы площадки несёт её Referer, без которого
  // CDN TikTok отвечает 403.
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "videoner:media") {
      // Ответ асинхронный: Instagram может спросить API сайта.
      videonerFindPageMedia().then(sendResponse, () => sendResponse(null));
      return true;
    }
    if (message?.type === "videoner:reddit-fetch") {
      redditFetch(message)
        .then((size) => sendResponse({ ok: true, size }))
        .catch((e) => sendResponse({ ok: false, error: String(e?.message ?? e) }));
      return true;
    }
    if (message?.type === "videoner:page-fetch") {
      pageFetch(message)
        .then((size) => sendResponse({ ok: true, size }))
        .catch((e) => sendResponse({ ok: false, error: String(e?.message ?? e) }));
      return true;
    }
    return false;
  });

  // Ход сообщаем не чаще раза в полсекунды: чаще окошку не нужно.
  const PROGRESS_EVERY_MS = 500;

  async function pageFetch({ url, filename, jobUrl }) {
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
    const total = Number(res.headers.get("content-length")) || null;
    const reader = res.body.getReader();
    const chunks = [];
    let received = 0;
    let reportedAt = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      received += value.length;
      if (Date.now() - reportedAt > PROGRESS_EVERY_MS) {
        reportedAt = Date.now();
        chrome.runtime.sendMessage({ type: "videoner:direct-progress", jobUrl, received, total }).catch(() => {});
      }
    }
    if (!received) throw new Error("empty file");

    saveBlob(new Blob(chunks, { type: res.headers.get("content-type") || "video/mp4" }), filename);
    return received;
  }

  // ---- Reddit: видео и звук отдельными файлами, склейка — reddit-mux.js ----

  // Лучшее видео и звук из DASH-плейлиста ролика. Не вышло — видео из
  // fallback_url, а звук ищем по обычным именам файлов Reddit.
  async function redditStreams(fallbackUrl, dashUrl, hasAudio) {
    let video = fallbackUrl;
    let audio = null;
    if (dashUrl) {
      try {
        const res = await fetch(dashUrl, { credentials: "omit" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const xml = new DOMParser().parseFromString(await res.text(), "application/xml");
        let bestVideo = null;
        let bestAudio = null;
        for (const rep of xml.getElementsByTagNameNS("*", "Representation")) {
          const set = rep.parentElement;
          const mime = rep.getAttribute("mimeType") || set?.getAttribute("mimeType") || set?.getAttribute("contentType") || "";
          const codecs = rep.getAttribute("codecs") || set?.getAttribute("codecs") || "";
          const base = rep.getElementsByTagNameNS("*", "BaseURL")[0]?.textContent?.trim();
          if (!base) continue;
          const item = { url: new URL(base, dashUrl).href, bandwidth: Number(rep.getAttribute("bandwidth")) || 0 };
          const isAudio = /audio/i.test(mime) || /^(mp4a|opus|ac-3|ec-3)/i.test(codecs);
          if (isAudio) {
            if (!bestAudio || item.bandwidth > bestAudio.bandwidth) bestAudio = item;
          } else if (!bestVideo || item.bandwidth > bestVideo.bandwidth) {
            bestVideo = item;
          }
        }
        if (bestVideo) video = bestVideo.url;
        if (bestAudio) audio = bestAudio.url;
      } catch (e) {
        console.debug("Videoner: reddit dash", e);
      }
    }
    if (!audio && hasAudio) {
      for (const name of ["DASH_AUDIO_128.mp4", "DASH_AUDIO_64.mp4", "DASH_audio.mp4", "audio"]) {
        const candidate = new URL(name, fallbackUrl).href;
        const res = await fetch(candidate, { method: "HEAD", credentials: "omit" }).catch(() => null);
        if (res?.ok) {
          audio = candidate;
          break;
        }
      }
    }
    return { video, audio };
  }

  // Качаем файлы разом, ход — общий по всем.
  async function fetchAll(urls, jobUrl) {
    const responses = await Promise.all(urls.map((u) => fetch(u, { credentials: "omit" })));
    for (const res of responses) if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
    const sizes = responses.map((res) => Number(res.headers.get("content-length")) || 0);
    const total = sizes.every(Boolean) ? sizes.reduce((a, b) => a + b, 0) : null;
    let received = 0;
    let reportedAt = 0;
    return Promise.all(
      responses.map(async (res) => {
        const reader = res.body.getReader();
        const chunks = [];
        let length = 0;
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
          length += value.length;
          received += value.length;
          if (Date.now() - reportedAt > PROGRESS_EVERY_MS) {
            reportedAt = Date.now();
            chrome.runtime.sendMessage({ type: "videoner:direct-progress", jobUrl, received, total }).catch(() => {});
          }
        }
        const bytes = new Uint8Array(length);
        let at = 0;
        for (const chunk of chunks) {
          bytes.set(chunk, at);
          at += chunk.length;
        }
        return bytes;
      })
    );
  }

  async function redditFetch({ url, dashUrl, hasAudio, duration, filename, jobUrl }) {
    const streams = await redditStreams(url, dashUrl, hasAudio);
    const [video, audio] = await fetchAll([streams.video, streams.audio].filter(Boolean), jobUrl);
    if (!video?.length) throw new Error("empty file");
    const file = audio ? videonerMergeFmp4(video, audio, duration) : video;
    saveBlob(new Blob([file], { type: "video/mp4" }), filename);
    return file.length;
  }

  // Ссылка на blob страницы с атрибутом download: такой файл браузер
  // сохраняет в «Загрузки» под нашим именем, как обычную загрузку.
  function saveBlob(blob, filename) {
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    link.download = filename;
    link.click();
    setTimeout(() => URL.revokeObjectURL(href), 60_000);
  }

  update();
  // Смена адреса без перезагрузки страницы не порождает общего события, на
  // которое можно положиться на всех площадках, — проще сверять адрес.
  setInterval(update, 1000);
  document.addEventListener("fullscreenchange", update);
})();
